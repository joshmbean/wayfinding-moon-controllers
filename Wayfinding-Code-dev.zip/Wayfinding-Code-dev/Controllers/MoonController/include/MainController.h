#ifndef MAIN_CONTROLLER_h
#define MAIN_CONTROLLER_H

void MainControllerSetup();
void MainControllerLoop();

#endif