#ifndef MOON_CONFIG_H
#define MOON_CONFIG_H
#include <Arduino.h>

// Cell structure: 2 Hemispheres, 4 Panels per Hemisphere, 8 Cells per Panel
#define NUM_HEMISPHERES 2
#define NUM_PANELS_PER_HEMISPHERE 4
#define NUM_CELLS_PER_PANEL 8
#define TOTAL_CELLS (NUM_HEMISPHERES * NUM_PANELS_PER_HEMISPHERE * NUM_CELLS_PER_PANEL)

// Configuration Structure
struct Config {
  uint16_t longTermAvgSamples;      // 0 to 65535
  uint16_t shortTermAvgSamples;     // 0 to 65535
  uint8_t brightness;               // 0 to 100 (%)
  uint16_t retriggerTime;           // 0 to 65535 mS
  uint16_t sampleTime;              // 0 to 65525 mS 
  uint8_t pressThreshold;           // Release Threshold to 255 // NOTE Reusedto specify cell control
  uint8_t releaseThreshold;         // 0 to 255 // NOTE REused to specify panel control
  uint8_t maxThreshold;            // Press Threshold to 255 // NOTE REused to specify hemisphere control
  String modeUser;                  // Base, Moth, Music, Colour, Simon, Standby, Debug, Flash
  String modeOverride;              // Base, Moth, Music, Colour, Simon, Standby, Debug, Flash
  bool modeOverrideEnabled;         // Enable/disable mode override
  uint8_t i2cFrequency;             // 1 to 100 kHz
  uint32_t startColour;             // 24-bit RGB (0xRRGGBB)
  uint32_t endColour;               // 24-bit RGB (0xRRGGBB)
  // Legacy cell defaults (kept for backward compatibility)
  int globalDefaultPressPressure;
  int globalDefaultReleasePressure;
  int globalDefaultRepressTime;
};

struct CellConfig {
  int pressPressure;      // -1 means use global default
  int releasePressure;   // -1 means use global default
  int repressTime;       // -1 means use global default (in milliseconds)
};

// WiFi AP Configuration Structure
struct WiFiConfig {
  String ssid;
  String password;
};

void saveConfig();
void saveWiFiConfig();
void loadConfig();

void initDefaultCellConfigs();
// Get effective cell config value (returns global default if cell value is -1)
int getEffectivePressPressure(int hemisphere, int panel, int cell);
int getEffectiveReleasePressure(int hemisphere, int panel, int cell);
int getEffectiveRepressTime(int hemisphere, int panel, int cell);

#endif