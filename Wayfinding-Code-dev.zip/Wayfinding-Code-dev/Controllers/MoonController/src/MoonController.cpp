/*
 * Wayfinding Moon ESP Controller
 * ESP32 Dev Module - Arduino Core Framework
 * 
 * Features:
 * - WiFi Access Point
 * - Web Server with Config Settings Page
 */ 

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>

#include <ArduinoJson.h>
#include <Update.h>
#include <Wire.h>

#include "MoonConfig.h"
#include "MainController.h"

#include <esp_now.h>
// #include "esp_now_midi.h"

extern Config globalConfig;
extern WiFiConfig wifiConfig;
extern CellConfig cellConfigs[NUM_HEMISPHERES][NUM_PANELS_PER_HEMISPHERE][NUM_CELLS_PER_PANEL];

// Forward declaration for sub-controller update function (defined in MainController.ino)
void updateSubController(uint8_t address, uint8_t* firmware, size_t size);

// Web Server
WebServer server(80);

// WebSocket Server for console logs
WebSocketsServer webSocket(81);

// Console log functions (similar to Serial.print/println)
void consolePrint(const String& message) {
  // Serial.print(message);
  String msg = message;  // Create non-const copy
  webSocket.broadcastTXT(msg);
}

void consolePrintln(const String& message) {
  // Serial.println(message);
  String msg = message + "\n";  // Create non-const copy
  webSocket.broadcastTXT(msg);
}

void consolePrint(int value) {
  // Serial.print(value);
  String msg = String(value);  // Create non-const String
  webSocket.broadcastTXT(msg);
}

void consolePrintln(int value) {
  // Serial.println(value);
  String msg = String(value) + "\n";  // Create non-const String
  webSocket.broadcastTXT(msg);
}

void consolePrint(float value) {
  // Serial.print(value);
  String msg = String(value);  // Create non-const String
  webSocket.broadcastTXT(msg);
}

void consolePrintln(float value) {
  // Serial.println(value);
  String msg = String(value) + "\n";  // Create non-const String
  webSocket.broadcastTXT(msg);
}

void consolePrintln() {
  // Serial.println();
  String msg = "\n";  // Create non-const String
  webSocket.broadcastTXT(msg);
}

void consolePrintf(const char* fmt, ...) {
    va_list args; // declare a variable argument list

    char buffer[64]; // declare a buffer to hold parsed string

    va_start(args, fmt); // call va_start on fixed parameter
    //thisArg = va_arg(args, <type>);
    vsnprintf(buffer, 64, fmt, args); // parse format string using vsnprintf
    va_end(args); // cleanup reference pointers
    Serial.print(buffer);
    consolePrint(buffer);	// transmit parsed string from buffer 
}

// WebSocket event handler
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.print("Client ");
      Serial.print(num);
      Serial.println(" disconnected");
      webSocket.broadcastTXT("Client " + String(num) + " disconnected\n");
      break;
    case WStype_CONNECTED:
      {
        IPAddress ip = webSocket.remoteIP(num);
        Serial.print("Client ");
        Serial.print(num);
        Serial.print(" connected from ");
        Serial.println(ip.toString());
        webSocket.broadcastTXT("Client " + String(num) + " connected from " + ip.toString() + "\n");
      }
      break;
    case WStype_TEXT:
      // Echo back received message (optional)
      // webSocket.sendTXT(num, payload);
      break;
    default:
      break;
  }
}



// API endpoint: GET /api/config
void handleGetConfig() {
  DynamicJsonDocument doc(4096);
  doc["longTermAvgSamples"] = globalConfig.longTermAvgSamples;
  doc["shortTermAvgSamples"] = globalConfig.shortTermAvgSamples;
  doc["brightness"] = globalConfig.brightness;
  doc["retriggerTime"] = globalConfig.retriggerTime;
  doc["sampleTime"] = globalConfig.sampleTime;
  doc["pressThreshold"] = globalConfig.pressThreshold;
  doc["releaseThreshold"] = globalConfig.releaseThreshold;
  doc["maxThreshold"] = globalConfig.maxThreshold;
  doc["modeOverride"] = globalConfig.modeOverride;
  doc["modeOverrideEnabled"] = globalConfig.modeOverrideEnabled;
  doc["i2cFrequency"] = globalConfig.i2cFrequency;
  doc["startColour"] = globalConfig.startColour;
  doc["endColour"] = globalConfig.endColour;
  // Legacy cell defaults (for backward compatibility)
  doc["globalDefaultPressPressure"] = globalConfig.globalDefaultPressPressure;
  doc["globalDefaultReleasePressure"] = globalConfig.globalDefaultReleasePressure;
  doc["globalDefaultRepressTime"] = globalConfig.globalDefaultRepressTime;
  
  // Create nested structure: hemispheres -> panels -> cells
  JsonArray hemispheres = doc.createNestedArray("hemispheres");
  for (int h = 0; h < NUM_HEMISPHERES; h++) {
    JsonObject hemisphere = hemispheres.createNestedObject();
    hemisphere["id"] = h;
    JsonArray panels = hemisphere.createNestedArray("panels");
    for (int p = 0; p < NUM_PANELS_PER_HEMISPHERE; p++) {
      JsonObject panel = panels.createNestedObject();
      panel["id"] = p;
      JsonArray cells = panel.createNestedArray("cells");
      for (int c = 0; c < NUM_CELLS_PER_PANEL; c++) {
        JsonObject cell = cells.createNestedObject();
        cell["id"] = c;
        cell["pressPressure"] = cellConfigs[h][p][c].pressPressure;
        cell["releasePressure"] = cellConfigs[h][p][c].releasePressure;
        cell["repressTime"] = cellConfigs[h][p][c].repressTime;
      }
    }
  }
  
  String response;
  serializeJson(doc, response);
  
  server.send(200, "application/json", response);
}

// API endpoint: GET /api/wifi
void handleGetWiFi() {
  DynamicJsonDocument doc(256);
  doc["ssid"] = wifiConfig.ssid;
  doc["password"] = wifiConfig.password;
  
  String response;
  serializeJson(doc, response);
  
  server.send(200, "application/json", response);
}

// API endpoint: POST /api/config
void handlePostConfig() {
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    
    DynamicJsonDocument doc(4096);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
      return;
    }
    
    // Update global config
    if (doc.containsKey("longTermAvgSamples")) {
      globalConfig.longTermAvgSamples = doc["longTermAvgSamples"].as<uint16_t>();
      if (globalConfig.longTermAvgSamples > 65535) globalConfig.longTermAvgSamples = 65535;
    }
    
    if (doc.containsKey("shortTermAvgSamples")) {
      globalConfig.shortTermAvgSamples = doc["shortTermAvgSamples"].as<uint16_t>();
      if (globalConfig.shortTermAvgSamples > 65535) globalConfig.shortTermAvgSamples = 65535;
    }
    
    if (doc.containsKey("brightness")) {
      globalConfig.brightness = doc["brightness"].as<uint8_t>();
      if (globalConfig.brightness > 100) globalConfig.brightness = 100;
    }
    
    if (doc.containsKey("retriggerTime")) {
      globalConfig.retriggerTime = doc["retriggerTime"].as<uint16_t>();
      if (globalConfig.retriggerTime > 65535) globalConfig.retriggerTime = 65535;
    }
    
    if (doc.containsKey("sampleTime")) {
      globalConfig.sampleTime = doc["sampleTime"].as<uint16_t>();
      if (globalConfig.sampleTime > 65525) globalConfig.sampleTime = 65525;
    }
    
    if (doc.containsKey("releaseThreshold")) {
      globalConfig.releaseThreshold = doc["releaseThreshold"].as<uint8_t>();
      if (globalConfig.releaseThreshold > 255) globalConfig.releaseThreshold = 255;
    }
    
    if (doc.containsKey("pressThreshold")) {
      globalConfig.pressThreshold = doc["pressThreshold"].as<uint8_t>();
      if (globalConfig.pressThreshold > 255) globalConfig.pressThreshold = 255;
      // Ensure pressThreshold >= releaseThreshold
      if (globalConfig.pressThreshold < globalConfig.releaseThreshold) {
        // globalConfig.pressThreshold = globalConfig.releaseThreshold;
      }
    }
    
    if (doc.containsKey("maxThreshold")) {
      globalConfig.maxThreshold = doc["maxThreshold"].as<uint8_t>();
      if (globalConfig.maxThreshold > 255) globalConfig.maxThreshold = 255;
      // Ensure maxThreshold >= pressThreshold
      if (globalConfig.maxThreshold < globalConfig.pressThreshold) {
        // globalConfig.maxThreshold = globalConfig.pressThreshold;
      }
    }
    
    if (doc.containsKey("modeOverride")) {
      String mode = doc["modeOverride"].as<String>();
      // Validate mode
      if (mode == "Base" || mode == "Moth" || mode == "Music" || mode == "Colour" || 
          mode == "Simon" || mode == "Standby" || mode == "Debug" || mode == "Flash") {
        globalConfig.modeOverride = mode;
      }
    }
    
    if (doc.containsKey("modeOverrideEnabled")) {
      globalConfig.modeOverrideEnabled = doc["modeOverrideEnabled"].as<bool>();
    }
    
    if (doc.containsKey("i2cFrequency")) {
      globalConfig.i2cFrequency = doc["i2cFrequency"].as<uint8_t>();
      if (globalConfig.i2cFrequency < 1) globalConfig.i2cFrequency = 1;
      if (globalConfig.i2cFrequency > 100) globalConfig.i2cFrequency = 100;
    }
    
    if (doc.containsKey("startColour")) {
      globalConfig.startColour = doc["startColour"].as<uint32_t>();
      // Ensure it's a valid 24-bit RGB value
      globalConfig.startColour = globalConfig.startColour & 0xFFFFFF;
    }
    
    if (doc.containsKey("endColour")) {
      globalConfig.endColour = doc["endColour"].as<uint32_t>();
      // Ensure it's a valid 24-bit RGB value
      globalConfig.endColour = globalConfig.endColour & 0xFFFFFF;
    }
    
    // Legacy cell defaults (for backward compatibility)
    if (doc.containsKey("globalDefaultPressPressure")) {
      globalConfig.globalDefaultPressPressure = doc["globalDefaultPressPressure"].as<int>();
    }
    
    if (doc.containsKey("globalDefaultReleasePressure")) {
      globalConfig.globalDefaultReleasePressure = doc["globalDefaultReleasePressure"].as<int>();
    }
    
    if (doc.containsKey("globalDefaultRepressTime")) {
      globalConfig.globalDefaultRepressTime = doc["globalDefaultRepressTime"].as<int>();
    }
    
    // Update cell configs from nested structure: hemispheres -> panels -> cells
    if (doc.containsKey("hemispheres") && doc["hemispheres"].is<JsonArray>()) {
      JsonArray hemispheres = doc["hemispheres"];
      int hCount = (hemispheres.size() < NUM_HEMISPHERES) ? hemispheres.size() : NUM_HEMISPHERES;
      
      for (int h = 0; h < hCount; h++) {
        JsonObject hemisphere = hemispheres[h];
        if (hemisphere.containsKey("panels") && hemisphere["panels"].is<JsonArray>()) {
          JsonArray panels = hemisphere["panels"];
          int pCount = (panels.size() < NUM_PANELS_PER_HEMISPHERE) ? panels.size() : NUM_PANELS_PER_HEMISPHERE;
          
          for (int p = 0; p < pCount; p++) {
            JsonObject panel = panels[p];
            if (panel.containsKey("cells") && panel["cells"].is<JsonArray>()) {
              JsonArray cells = panel["cells"];
              int cCount = (cells.size() < NUM_CELLS_PER_PANEL) ? cells.size() : NUM_CELLS_PER_PANEL;
              
              for (int c = 0; c < cCount; c++) {
                JsonObject cell = cells[c];
                if (cell.containsKey("pressPressure")) {
                  cellConfigs[h][p][c].pressPressure = cell["pressPressure"].as<int>();
                }
                if (cell.containsKey("releasePressure")) {
                  cellConfigs[h][p][c].releasePressure = cell["releasePressure"].as<int>();
                }
                if (cell.containsKey("repressTime")) {
                  cellConfigs[h][p][c].repressTime = cell["repressTime"].as<int>();
                }
              }
            }
          }
        }
      }
    }
    
    // Save to preferences
    saveConfig();
    
    server.send(200, "application/json", "{\"status\":\"ok\"}");
  } else {
    server.send(400, "application/json", "{\"error\":\"No data\"}");
  }
}

// API endpoint: GET /api/diagnostics
void handleGetDiagnostics() {
  DynamicJsonDocument doc(512);
  doc["freeHeap"] = ESP.getFreeHeap();
  doc["uptime"] = millis() / 1000;
  doc["chipModel"] = ESP.getChipModel();
  doc["chipRevision"] = ESP.getChipRevision();
  doc["cpuFreq"] = ESP.getCpuFreqMHz();
  doc["flashSize"] = ESP.getFlashChipSize();
  
  String response;
  serializeJson(doc, response);
  
  server.send(200, "application/json", response);
}

// Handle firmware update
void handleUpdate() {
  HTTPUpload& upload = server.upload();
  
  if (upload.status == UPLOAD_FILE_START) {
    consolePrint("Update: ");
    consolePrintln(upload.filename);
    
    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
      Update.printError(Serial);
      String errorMsg = "Update failed: " + String(Update.errorString());
      consolePrintln(errorMsg);
    }
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      Update.printError(Serial);
      String errorMsg = "Write failed: " + String(Update.errorString());
      consolePrintln(errorMsg);
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (Update.end(true)) {
      consolePrintln("Update Success: " + String(upload.totalSize) + " bytes");
      consolePrintln("Rebooting...");
      server.sendHeader("Connection", "close");
      server.send(200, "text/plain", "Update successful! Device restarting...");
      delay(1000);
      ESP.restart();
    } else {
      Update.printError(Serial);
      String errorMsg = "Update failed: " + String(Update.errorString());
      consolePrintln(errorMsg);
      server.send(500, "text/plain", errorMsg);
    }
  } else {
    String errorMsg = "Update failed: " + String(Update.errorString());
    consolePrintln(errorMsg);
    server.send(500, "text/plain", errorMsg);
  }
}

// Handle firmware update page
void handleUpdatePage() {
  server.sendHeader("Connection", "close");
  server.send(200, "text/plain", (Update.hasError()) ? "FAIL" : "OK");
}

// Sub-controller firmware update buffer
#define MAX_SUB_FIRMWARE_SIZE (32 * 1024)  // 32KB max firmware size
uint8_t* subFirmwareBuffer = nullptr;
size_t subFirmwareSize = 0;
size_t subFirmwareOffset = 0;
uint8_t subControllerAddress = 0x02;  // Default sub-controller address

// Handle sub-controller firmware update
void handleSubUpdate() {
  HTTPUpload& upload = server.upload();
  
  if (upload.status == UPLOAD_FILE_START) {
    consolePrint("Sub-controller Update: ");
    consolePrintln(upload.filename);
    
    // Get address from query parameter if available
    if (server.hasArg("address")) {
      String addrStr = server.arg("address");
      uint8_t addr = (uint8_t)strtol(addrStr.c_str(), nullptr, 16);
      if (addr > 0 && addr <= 127) {
        subControllerAddress = addr;
        consolePrintf("Using I2C address: 0x%02X\n", subControllerAddress);
      }
    }
    
    // Allocate buffer for firmware
    if (subFirmwareBuffer != nullptr) {
      free(subFirmwareBuffer);
      subFirmwareBuffer = nullptr;
    }
    
    subFirmwareSize = 0;
    subFirmwareOffset = 0;
    
    // Allocate initial buffer (will reallocate if needed)
    subFirmwareBuffer = (uint8_t*)malloc(MAX_SUB_FIRMWARE_SIZE);
    if (subFirmwareBuffer == nullptr) {
      consolePrintln("Error: Failed to allocate memory for firmware");
      server.send(500, "text/plain", "Failed to allocate memory");
      return;
    }
    
    consolePrintf("Allocated buffer for sub-controller firmware (max %u bytes)\n", MAX_SUB_FIRMWARE_SIZE);
    
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    // Check if we have enough space
    if (subFirmwareOffset + upload.currentSize > MAX_SUB_FIRMWARE_SIZE) {
      consolePrintln("Error: Firmware too large");
      free(subFirmwareBuffer);
      subFirmwareBuffer = nullptr;
      server.send(500, "text/plain", "Firmware too large (max 64KB)");
      return;
    }
    
    // Copy data to buffer
    memcpy(subFirmwareBuffer + subFirmwareOffset, upload.buf, upload.currentSize);
    subFirmwareOffset += upload.currentSize;
    subFirmwareSize = subFirmwareOffset;
    
    // Progress update every 4KB
    if ((subFirmwareSize % 4096) == 0 || upload.currentSize < upload.totalSize) {
      uint8_t percent = (uint8_t)((subFirmwareSize * 100) / upload.totalSize);
      consolePrintf("Sub-controller upload progress: %u%% (%u/%u bytes)\n", 
                    percent, subFirmwareSize, upload.totalSize);
    }
    
  } else if (upload.status == UPLOAD_FILE_END) {
    consolePrintf("Sub-controller firmware upload complete: %u bytes\n", subFirmwareSize);
    
    if (subFirmwareBuffer != nullptr && subFirmwareSize > 0) {
      // Call updateSubController function
      consolePrintf("Starting update for sub-controller at address 0x%02X\n", subControllerAddress);
      updateSubController(subControllerAddress, subFirmwareBuffer, subFirmwareSize);
      
      // Clean up
      free(subFirmwareBuffer);
      subFirmwareBuffer = nullptr;
      subFirmwareSize = 0;
      subFirmwareOffset = 0;
      
      server.sendHeader("Connection", "close");
      server.send(200, "text/plain", "Sub-controller update successful!");
    } else {
      consolePrintln("Error: No firmware data received");
      server.send(500, "text/plain", "No firmware data received");
    }
    
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    consolePrintln("Sub-controller firmware upload aborted");
    if (subFirmwareBuffer != nullptr) {
      free(subFirmwareBuffer);
      subFirmwareBuffer = nullptr;
    }
    subFirmwareSize = 0;
    subFirmwareOffset = 0;
    server.send(500, "text/plain", "Upload aborted");
  }
}

// Handle sub-controller firmware update page
void handleSubUpdatePage() {
  server.sendHeader("Connection", "close");
  server.send(200, "text/plain", "OK");
}



// Handle root path - serve HTML page
void handleRoot() {
//     server.sendHeader("Cache-Control", "no-cache, no-store, must-revalidate");
// server.sendHeader("Pragma", "no-cache");
// server.sendHeader("Expires", "-1");
// server.setContentLength(CONTENT_LENGTH_UNKNOWN);
// // here begin chunked transfer
//     server.send(200, "text/html", "");
// server.sendContent(WEBPAGE_BIG_0); 
// server.sendContent(WEBPAGE_BIG_1); 
// server.sendContent(WEBPAGE_BIG_2); 
// server.sendContent(WEBPAGE_BIG_3);
// server.sendContent(WEBPAGE_BIG_4);
// server.sendContent(WEBPAGE_BIG_5);
  server.send(200, "text/html", R"HTML(<!doctypehtml><html lang=en><meta charset=UTF-8><meta content="width=device-width,initial-scale=1"name=viewport><title>Wayfinding Moon - Configuration</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,sans-serif;background:linear-gradient(135deg,#667eea 0,#764ba2 100%);min-height:100vh;padding:20px}.container{max-width:1200px;margin:0 auto;background:#fff;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,.2);overflow:hidden}.header{background:#2c3e50;color:#fff;padding:20px 30px;display:flex;align-items:center;gap:20px}.logo{width:60px;height:60px;background:#3498db;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:700}.header h1{flex:1;font-size:28px}.content{padding:30px}.section{margin-bottom:30px}.section-title{font-size:24px;color:#2c3e50;margin-bottom:20px;padding-bottom:10px;border-bottom:2px solid #ecf0f1}.form-group{margin-bottom:20px}label{display:block;margin-bottom:8px;color:#34495e;font-weight:500}input[type=color],input[type=number],input[type=text]{width:100%;padding:12px;border:2px solid #ecf0f1;border-radius:6px;font-size:16px;transition:border-color .3s}input[type=number]:focus,input[type=text]:focus{outline:0;border-color:#3498db}.cell-item{background:#f8f9fa;border:2px solid #e9ecef;border-radius:8px;margin-bottom:15px;overflow:hidden;transition:all .3s}.cell-header{padding:15px 20px;background:#e9ecef;cursor:pointer;display:flex;justify-content:space-between;align-items:center;user-select:none}.cell-header:hover{background:#dee2e6}.cell-header h3{margin:0;color:#2c3e50;font-size:18px}.cell-toggle{font-size:20px;transition:transform .3s}.cell-toggle.expanded{transform:rotate(180deg)}.cell-content{padding:0 20px;max-height:0;overflow:hidden;transition:max-height .3s ease-out,padding .3s ease-out}.cell-content.expanded{max-height:500px;padding:20px;overflow-y:auto;overflow-x:hidden}#cellSettings{max-height:80vh;overflow-y:auto;overflow-x:hidden}[id^=hemispherePanels],[id^=panelCells]{max-height:400px;overflow-y:auto;overflow-x:hidden}#cellSettings::-webkit-scrollbar,.cell-content.expanded::-webkit-scrollbar,[id^=hemispherePanels]::-webkit-scrollbar,[id^=panelCells]::-webkit-scrollbar{width:8px}#cellSettings::-webkit-scrollbar-track,.cell-content.expanded::-webkit-scrollbar-track,[id^=hemispherePanels]::-webkit-scrollbar-track,[id^=panelCells]::-webkit-scrollbar-track{background:#f1f1f1;border-radius:4px}#cellSettings::-webkit-scrollbar-thumb,.cell-content.expanded::-webkit-scrollbar-thumb,[id^=hemispherePanels]::-webkit-scrollbar-thumb,[id^=panelCells]::-webkit-scrollbar-thumb{background:#888;border-radius:4px}#cellSettings::-webkit-scrollbar-thumb:hover,.cell-content.expanded::-webkit-scrollbar-thumb:hover,[id^=hemispherePanels]::-webkit-scrollbar-thumb:hover,[id^=panelCells]::-webkit-scrollbar-thumb:hover{background:#555}#cellSettings,.cell-content.expanded,[id^=hemispherePanels],[id^=panelCells]{scrollbar-width:thin;scrollbar-color:#888 #f1f1f1}.btn{background:#3498db;color:#fff;border:none;padding:12px 30px;border-radius:6px;font-size:16px;font-weight:500;cursor:pointer;transition:background .3s}.btn:hover{background:#2980b9}.btn-success{background:#27ae60}.btn-success:hover{background:#229954}.button-group{display:flex;gap:15px;margin-top:30px}.status-message{padding:12px;border-radius:6px;margin-bottom:20px;display:none}.status-message.success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;display:block}.status-message.error{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;display:block}.tabs{display:flex;border-bottom:2px solid #ecf0f1;margin-bottom:20px}.tab{padding:15px 30px;cursor:pointer;background:#f8f9fa;border:none;border-bottom:3px solid transparent;font-size:16px;font-weight:500;color:#6c757d;transition:all .3s}.tab:hover{background:#e9ecef;color:#2c3e50}.tab.active{background:#fff;color:#2c3e50;border-bottom-color:#3498db}.tab-content{display:none}.tab-content.active{display:block}.help-text{font-size:12px;color:#6c757d;margin-top:5px;font-style:italic}.radio-grid{display:grid;grid-template-columns:repeat(2,1fr);grid-template-rows:repeat(4,1fr);gap:15px;margin-top:20px}.radio-option{display:flex;align-items:center;padding:12px;border:2px solid #e9ecef;border-radius:6px;cursor:pointer;transition:all .3s;background:#f8f9fa}.radio-option:hover{background:#e9ecef;border-color:#3498db}.radio-option input[type=radio]{margin-right:10px;width:18px;height:18px;cursor:pointer}.radio-option input[type=radio]:checked+span{font-weight:600;color:#2c3e50}.radio-option:has(input[type=radio]:checked){background:#e3f2fd;border-color:#3498db}.radio-option span{flex:1;font-size:16px;color:#34495e}.radio-grid.disabled{opacity:.5;pointer-events:none}.radio-grid.disabled .radio-option{background:#e9ecef;cursor:not-allowed}.toggle-switch{position:relative;display:inline-block;width:60px;height:34px}.toggle-switch input{opacity:0;width:0;height:0}.toggle-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc;transition:.4s;border-radius:34px}.toggle-slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:4px;background-color:#fff;transition:.4s;border-radius:50%}.toggle-switch input:checked+.toggle-slider{background-color:#3498db}.toggle-switch input:checked+.toggle-slider:before{transform:translateX(26px)}.toggle-switch input:focus+.toggle-slider{box-shadow:0 0 1px #3498db}.console-container{background:#1e1e1e;border-radius:6px;padding:15px;font-family:'Courier New',monospace;height:600px;overflow-y:auto;overflow-x:hidden}.console-log{color:#d4d4d4;font-size:14px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word;margin:0;padding:0}.console-container::-webkit-scrollbar{width:8px}.console-container::-webkit-scrollbar-track{background:#252526;border-radius:4px}.console-container::-webkit-scrollbar-thumb{background:#424242;border-radius:4px}.console-container::-webkit-scrollbar-thumb:hover{background:#4e4e4e}.console-status{display:inline-block;padding:5px 10px;border-radius:4px;font-size:12px;font-weight:500;margin-bottom:10px}.console-status.connected{background:#27ae60;color:#fff}.console-status.disconnected{background:#e74c3c;color:#fff}.console-status.connecting{background:#f39c12;color:#fff}.upload-area{border:3px dashed #3498db;border-radius:8px;padding:40px;text-align:center;background:#f8f9fa;transition:all .3s;min-height:200px;display:flex;align-items:center;justify-content:center}.upload-area.drag-over{border-color:#27ae60;background:#e8f5e9}.upload-area:hover{border-color:#2980b9;background:#e3f2fd}#uploadContent{width:100%}</style><div class=container><div class=header><div class=logo>WM</div><h1>Wayfinding Moon Configuration</h1></div><div class=content><div class=status-message id=statusMessage></div><div class=tabs><button class="tab active"onclick='switchTab("config")'>Configuration</button> <button class=tab onclick='switchTab("wifi")'>WiFi AP Settings</button> <button class=tab onclick='switchTab("console")'>Console</button> <button class=tab onclick='switchTab("diagnostics")'>Diagnostics</button></div><div class="tab-content active"id=configTab><form id=configForm><div class=section><h2 class=section-title>Global Settings</h2><div class=form-group><label for=longTermAvgSamples>Long Term Average Samples</label> <input id=longTermAvgSamples name=longTermAvgSamples type=number required max=65535 min=0></div><div class=form-group><label for=shortTermAvgSamples>Short Term Average Samples</label> <input id=shortTermAvgSamples name=shortTermAvgSamples type=number required max=65535 min=0></div><div class=form-group><label for=brightness>Brightness (%)</label> <input id=brightness name=brightness type=number required max=100 min=0></div><div class=form-group><label for=retriggerTime>Retrigger Time (mS)</label> <input id=retriggerTime name=retriggerTime type=number required max=65535 min=0></div><div class=form-group><label for=sampleTime>Sample Time (mS)</label> <input id=sampleTime name=sampleTime type=number required max=65525 min=0></div><div class=form-group><label for=pressThreshold>Cell Control</label> <input id=pressThreshold name=pressThreshold type=number><p class=help-text>Range: Release Threshold to 255</div><div class=form-group><label for=releaseThreshold>Panel Control</label> <input id=releaseThreshold name=releaseThreshold type=number></div><div class=form-group><label for=maxThreshold>Hemisphere Control</label> <input id=maxThreshold name=maxThreshold type=number><p class=help-text>Range: Press Threshold to 255</div><div class=form-group><label for=i2cFrequency>I2C Frequency (kHz)</label> <input id=i2cFrequency name=i2cFrequency type=number required max=100 min=1></div></div><div class=section><div style=display:flex;align-items:center;justify-content:space-between;margin-bottom:20px><h2 class=section-title style=margin:0>Mode Override</h2><label class=toggle-switch><input id=modeOverrideEnabled name=modeOverrideEnabled type=checkbox> <span class=toggle-slider></span></label></div><div class=radio-grid id=modeOverrideGrid><label class=radio-option><input id=modeBase name=modeOverride type=radio value=Base> <span>Base</span></label> <label class=radio-option><input id=modeMoth name=modeOverride type=radio value=Moth> <span>Save Cal</span></label> <label class=radio-option><input id=modeMusic name=modeOverride type=radio value=Music> <span>Music</span></label> <label class=radio-option><input id=modeColour name=modeOverride type=radio value=Colour> <span>Light</span></label> <label class=radio-option><input id=modeSimon name=modeOverride type=radio value=Simon> <span>Simon</span></label> <label class=radio-option><input id=modeStandby name=modeOverride type=radio value=Standby> <span>Orbit</span></label> <label class=radio-option><input id=modeDebug name=modeOverride type=radio value=Debug> <span>Debug</span></label> <label class=radio-option><input id=modeFlash name=modeOverride type=radio value=Flash> <span>Flash</span></label></div></div><div class=section><h2 class=section-title>Colour Gradient</h2><div class=form-group><label for=startColour>Start Colour</label><div style=display:flex;gap:10px;align-items:center><input id=startColourPicker name=startColourPicker type=color style=width:80px;height:40px;cursor:pointer> <input id=startColour name=startColour required maxlength=6 pattern=^[0-9A-Fa-f]{6}$ placeholder=RRGGBB style=flex:1></div><p class=help-text>24-bit RGB value (hex format: RRGGBB)</div><div class=form-group><label for=endColour>End Colour</label><div style=display:flex;gap:10px;align-items:center><input id=endColourPicker name=endColourPicker type=color style=width:80px;height:40px;cursor:pointer> <input id=endColour name=endColour required maxlength=6 pattern=^[0-9A-Fa-f]{6}$ placeholder=RRGGBB style=flex:1></div><p class=help-text>24-bit RGB value (hex format: RRGGBB)</div></div><div class=section><h2 class=section-title>Cell Settings</h2><p class=help-text>Leave fields empty to use global defaults. Custom values override global defaults.<p class=help-text>Structure: 2 Hemispheres → 4 Panels → 8 Cells each<div id=cellSettings></div></div><div class=button-group><button class="btn btn-success"type=submit>Save Configuration</button> <button class=btn onclick=loadConfig() type=button>Reload</button></div></form></div><div class=tab-content id=wifiTab><form id=wifiForm><div class=section><h2 class=section-title>WiFi Access Point Settings</h2><p class=help-text>Changes to WiFi settings will take effect after device restart.<div class=form-group><label for=wifiSSID>Access Point SSID</label> <input id=wifiSSID name=wifiSSID required maxlength=32></div><div class=form-group><label for=wifiPassword>Access Point Password</label> <input id=wifiPassword name=wifiPassword type=password required maxlength=63 minlength=8><p class=help-text>Minimum 8 characters required for WPA2 security.</div><div class=button-group><button class="btn btn-success"type=submit>Save WiFi Settings</button> <button class=btn onclick=loadWiFiConfig() type=button>Reload</button></div></div></form></div><div class=tab-content id=consoleTab><div class=section><h2 class=section-title>Console Logs</h2><div><span id=consoleStatus class="console-status disconnected">Disconnected</span> <button class=btn onclick=clearConsole() style=float:right;margin-bottom:10px>Clear</button></div><div class=console-container id=consoleOutput><pre class=console-log id=consoleLog></pre></div></div></div><div class=tab-content id=diagnosticsTab><div class=section><h2 class=section-title>System Diagnostics</h2><div class=form-group><h3 style=margin-bottom:15px;color:#2c3e50>System Information</h3><div id=systemInfo style=background:#f8f9fa;padding:15px;border-radius:6px;font-family:monospace;font-size:14px><div>Free Heap: <span id=freeHeap>-</span> bytes</div><div>Uptime: <span id=uptime>-</span></div><div>Chip Model: <span id=chipModel>-</span></div><div>Chip Revision: <span id=chipRevision>-</span></div><div>CPU Frequency: <span id=cpuFreq>-</span> MHz</div><div>Flash Size: <span id=flashSize>-</span> bytes</div></div></div><div class=section style=margin-top:30px><h2 class=section-title>Firmware Update</h2><p class=help-text>Upload a new firmware binary file (.bin) to update the device. The device will restart after a successful update.<div class=upload-area id=uploadArea><div id=uploadContent><div style=font-size:48px;margin-bottom:10px>📁</div><p style=font-size:16px;margin-bottom:5px>Drag and drop firmware file here<p style=font-size:14px;color:#6c757d>or</p><label for=firmwareFile class=btn style=margin-top:10px;cursor:pointer;display:inline-block>Browse Files <input id=firmwareFile type=file style=display:none accept=.bin onchange=handleFileSelect(this.files)></label></div><div id=uploadProgress style=display:none><div style=margin-bottom:10px><strong>Uploading: <span id=fileName>-</span></strong></div><div style=background:#e9ecef;border-radius:4px;height:30px;position:relative;overflow:hidden><div id=progressBar style="background:#3498db;height:100%;width:0%;transition:width .3s;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700"><span id=progressText>0%</span></div></div><div id=uploadStatus style=margin-top:10px;font-size:14px></div></div></div></div><div class=section style=margin-top:30px><h2 class=section-title>Sub-controller Firmware Update</h2><p class=help-text>Upload a new firmware binary file (.bin) to update the sub-controller device via I2C bootloader.<div class=upload-area id=subUploadArea><div id=subUploadContent><div style=font-size:48px;margin-bottom:10px>📁</div><p style=font-size:16px;margin-bottom:5px>Drag and drop firmware file here<p style=font-size:14px;color:#6c757d>or</p><label for=subFirmwareFile class=btn style=margin-top:10px;cursor:pointer;display:inline-block>Browse Files <input id=subFirmwareFile type=file style=display:none accept=.bin onchange=handleSubFileSelect(this.files)></label></div><div id=subUploadProgress style=display:none><div style=margin-bottom:10px><strong>Uploading: <span id=subFileName>-</span></strong></div><div style=background:#e9ecef;border-radius:4px;height:30px;position:relative;overflow:hidden><div id=subProgressBar style="background:#3498db;height:100%;width:0%;transition:width .3s;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700"><span id=subProgressText>0%</span></div></div><div id=subUploadStatus style=margin-top:10px;font-size:14px></div></div></div></div></div></div></div></div><script>let globalDefaults = {
            pressPressure: 100,
            releasePressure: 50,
            repressTime: 500
        };
        
        function showStatus(message, isError = false) {
            const statusEl = document.getElementById('statusMessage');
            statusEl.textContent = message;
            statusEl.className = 'status-message ' + (isError ? 'error' : 'success');
            setTimeout(() => {
                statusEl.className = 'status-message';
            }, 3000);
        }
        
        function switchTab(tabName) {
            // Stop system info updates if leaving diagnostics tab
            if (document.getElementById('diagnosticsTab').classList.contains('active')) {
                stopSystemInfoUpdates();
            }
            
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            if (tabName === 'config') {
                document.getElementById('configTab').classList.add('active');
                document.querySelectorAll('.tab')[0].classList.add('active');
            } else if (tabName === 'wifi') {
                document.getElementById('wifiTab').classList.add('active');
                document.querySelectorAll('.tab')[1].classList.add('active');
            } else if (tabName === 'console') {
                document.getElementById('consoleTab').classList.add('active');
                document.querySelectorAll('.tab')[2].classList.add('active');
                // Connect WebSocket when console tab is opened
                connectWebSocket();
            } else if (tabName === 'diagnostics') {
                document.getElementById('diagnosticsTab').classList.add('active');
                document.querySelectorAll('.tab')[3].classList.add('active');
                // Load system info when diagnostics tab is opened
                loadSystemInfo();
                startSystemInfoUpdates();
            }
        }
        
        // WebSocket connection for console logs
        let ws = null;
        let reconnectTimeout = null;
        
        function connectWebSocket() {
            if (ws && ws.readyState === WebSocket.OPEN) {
                return; // Already connected
            }
            
            updateConsoleStatus('connecting', 'Connecting...');
            
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = protocol + '//' + window.location.hostname + ':81';
            
            try {
                ws = new WebSocket(wsUrl);
                
                ws.onopen = function() {
                    updateConsoleStatus('connected', 'Connected');
                    if (reconnectTimeout) {
                        clearTimeout(reconnectTimeout);
                        reconnectTimeout = null;
                    }
                };
                
                ws.onmessage = function(event) {
                    appendConsoleLog(event.data);
                };
                
                ws.onerror = function(error) {
                    console.error('WebSocket error:', error);
                    updateConsoleStatus('disconnected', 'Connection Error');
                };
                
                ws.onclose = function() {
                    updateConsoleStatus('disconnected', 'Disconnected');
                    // Attempt to reconnect after 3 seconds
                    if (!reconnectTimeout) {
                        reconnectTimeout = setTimeout(function() {
                            reconnectTimeout = null;
                            if (document.getElementById('consoleTab').classList.contains('active')) {
                                connectWebSocket();
                            }
                        }, 3000);
                    }
                };
            } catch (error) {
                console.error('Failed to create WebSocket:', error);
                updateConsoleStatus('disconnected', 'Connection Failed');
            }
        }
        
        function updateConsoleStatus(status, text) {
            const statusEl = document.getElementById('consoleStatus');
            statusEl.className = 'console-status ' + status;
            statusEl.textContent = text;
        }
        
        function appendConsoleLog(message) {
            const logEl = document.getElementById('consoleLog');
            logEl.textContent += message;
            
            // Auto-scroll to bottom
            const container = document.getElementById('consoleOutput');
            container.scrollTop = container.scrollHeight;
            
            // Limit log size to prevent memory issues (keep last 50000 characters)
            if (logEl.textContent.length > 50000) {
                logEl.textContent = logEl.textContent.substring(logEl.textContent.length - 50000);
            }
        }
        
        function clearConsole() {
            document.getElementById('consoleLog').textContent = '';
        }
        
        function toggleHemisphere(hemisphereIndex) {
            const content = document.getElementById('hemisphereContent' + hemisphereIndex);
            const toggle = document.getElementById('hemisphereToggle' + hemisphereIndex);
            content.classList.toggle('expanded');
            toggle.classList.toggle('expanded');
        }
        
        function togglePanel(hemisphereIndex, panelIndex) {
            const content = document.getElementById('panelContent' + hemisphereIndex + '_' + panelIndex);
            const toggle = document.getElementById('panelToggle' + hemisphereIndex + '_' + panelIndex);
            content.classList.toggle('expanded');
            toggle.classList.toggle('expanded');
        }
        
        function toggleCell(hemisphereIndex, panelIndex, cellIndex) {
            const content = document.getElementById('cellContent' + hemisphereIndex + '_' + panelIndex + '_' + cellIndex);
            const toggle = document.getElementById('cellToggle' + hemisphereIndex + '_' + panelIndex + '_' + cellIndex);
            content.classList.toggle('expanded');
            toggle.classList.toggle('expanded');
        }
        
        function generateCellSettings() {
            const container = document.getElementById('cellSettings');
            container.innerHTML = "";
            
            // Update global defaults for placeholders (using legacy defaults)
            globalDefaults.pressPressure = 100;
            globalDefaults.releasePressure = 50;
            globalDefaults.repressTime = 500;
            
            // Generate structure: 2 Hemispheres -> 4 Panels -> 8 Cells
            for (let h = 0; h < 2; h++) {
                const hemisphereDiv = document.createElement('div');
                hemisphereDiv.className = 'cell-item';
                hemisphereDiv.innerHTML = 
                    '<div class="cell-header" onclick="toggleHemisphere(' + h + ')">' +
                        '<h3>Hemisphere ' + (h + 1) + '</h3>' +
                        '<span class="cell-toggle" id="hemisphereToggle' + h + '">▼</span>' +
                    '</div>' +
                    '<div class="cell-content" id="hemisphereContent' + h + '">' +
                        '<div id="hemispherePanels' + h + '"></div>' +
                    '</div>';
                container.appendChild(hemisphereDiv);
                
                // Generate panels for this hemisphere
                const panelsContainer = document.getElementById('hemispherePanels' + h);
                for (let p = 0; p < 4; p++) {
                    const panelDiv = document.createElement('div');
                    panelDiv.className = 'cell-item';
                    panelDiv.style.marginLeft = '20px';
                    panelDiv.innerHTML = 
                        '<div class="cell-header" onclick="togglePanel(' + h + ',' + p + ')">' +
                            '<h3>Panel ' + (p + 1) + '</h3>' +
                            '<span class="cell-toggle" id="panelToggle' + h + '_' + p + '">▼</span>' +
                        '</div>' +
                        '<div class="cell-content" id="panelContent' + h + '_' + p + '">' +
                            '<div id="panelCells' + h + '_' + p + '"></div>' +
                        '</div>';
                    panelsContainer.appendChild(panelDiv);
                    
                    // Generate cells for this panel
                    const cellsContainer = document.getElementById('panelCells' + h + '_' + p);
                    for (let c = 0; c < 8; c++) {
                        const cellDiv = document.createElement('div');
                        cellDiv.className = 'cell-item';
                        cellDiv.style.marginLeft = '20px';
                        cellDiv.innerHTML = 
                            '<div class="cell-header" onclick="toggleCell(' + h + ',' + p + ',' + c + ')">' +
                                '<h3>Cell ' + (c + 1) + '</h3>' +
                                '<span class="cell-toggle" id="cellToggle' + h + '_' + p + '_' + c + '">▼</span>' +
                            '</div>' +
                            '<div class="cell-content" id="cellContent' + h + '_' + p + '_' + c + '">' +
                                '<div class="form-group">' +
                                    '<label for="cell' + h + '_' + p + '_' + c + '_press">Press Pressure</label>' +
                                    '<input type="number" id="cell' + h + '_' + p + '_' + c + '_press" name="cell' + h + '_' + p + '_' + c + '_press" min="0" placeholder="Uses global default (' + globalDefaults.pressPressure + ')">' +
                                    '<p class="help-text">Leave empty to use global default</p>' +
                                '</div>' +
                                '<div class="form-group">' +
                                    '<label for="cell' + h + '_' + p + '_' + c + '_release">Release Pressure</label>' +
                                    '<input type="number" id="cell' + h + '_' + p + '_' + c + '_release" name="cell' + h + '_' + p + '_' + c + '_release" min="0" placeholder="Uses global default (' + globalDefaults.releasePressure + ')">' +
                                    '<p class="help-text">Leave empty to use global default</p>' +
                                '</div>' +
                                '<div class="form-group">' +
                                    '<label for="cell' + h + '_' + p + '_' + c + '_repress">Re-press Time (ms)</label>' +
                                    '<input type="number" id="cell' + h + '_' + p + '_' + c + '_repress" name="cell' + h + '_' + p + '_' + c + '_repress" min="0" placeholder="Uses global default (' + globalDefaults.repressTime + ')">' +
                                    '<p class="help-text">Leave empty to use global default</p>' +
                                '</div>' +
                            '</div>';
                        cellsContainer.appendChild(cellDiv);
                    }
                }
            }
        }
        
        function updateCellSettings() {
            // Regenerate with updated global defaults
            generateCellSettings();
            loadCellConfigs();
        }
        
        function validateThresholds() {
            const releaseThreshold = parseInt(document.getElementById('releaseThreshold').value) || 0;
            const pressThreshold = parseInt(document.getElementById('pressThreshold').value) || 0;
            const maxThreshold = parseInt(document.getElementById('maxThreshold').value) || 0;
            
            // Update min/max constraints dynamically
            const pressInput = document.getElementById('pressThreshold');
            const maxInput = document.getElementById('maxThreshold');
            
            pressInput.min = 0;//releaseThreshold;
            maxInput.min = 0;//pressThreshold;
            
            // Validate current values
            //if (pressThreshold < releaseThreshold) {
                //pressInput.setCustomValidity('Press Threshold must be >= Release Threshold');
           // } else {
                pressInput.setCustomValidity('');
           // }
            
            //if (maxThreshold < pressThreshold) {
             //   maxInput.setCustomValidity('Max Threshold must be >= Press Threshold');
            //} else {
                maxInput.setCustomValidity('');
            //}
        }
        
        async function loadConfig() {
            try {
                const response = await fetch('/api/config');
                const data = await response.json();
                
                // Load new global settings
                if (data.longTermAvgSamples !== undefined) {
                    document.getElementById('longTermAvgSamples').value = data.longTermAvgSamples;
                }
                if (data.shortTermAvgSamples !== undefined) {
                    document.getElementById('shortTermAvgSamples').value = data.shortTermAvgSamples;
                }
                if (data.brightness !== undefined) {
                    document.getElementById('brightness').value = data.brightness;
                }
                if (data.retriggerTime !== undefined) {
                    document.getElementById('retriggerTime').value = data.retriggerTime;
                }
                if (data.sampleTime !== undefined) {
                    document.getElementById('sampleTime').value = data.sampleTime;
                }
                if (data.pressThreshold !== undefined) {
                    document.getElementById('pressThreshold').value = data.pressThreshold;
                }
                if (data.releaseThreshold !== undefined) {
                    document.getElementById('releaseThreshold').value = data.releaseThreshold;
                }
                if (data.maxThreshold !== undefined) {
                    document.getElementById('maxThreshold').value = data.maxThreshold;
                }
                if (data.i2cFrequency !== undefined) {
                    document.getElementById('i2cFrequency').value = data.i2cFrequency;
                }
                if (data.modeOverrideEnabled !== undefined) {
                    document.getElementById('modeOverrideEnabled').checked = data.modeOverrideEnabled;
                    updateModeOverrideState(data.modeOverrideEnabled);
                }
                if (data.modeOverride !== undefined) {
                    const modeRadio = document.getElementById('mode' + data.modeOverride);
                    if (modeRadio) {
                        modeRadio.checked = true;
                    }
                }
                if (data.startColour !== undefined) {
                    const hexColour = '#' + data.startColour.toString(16).padStart(6, '0').toUpperCase();
                    document.getElementById('startColour').value = hexColour.substring(1);
                    document.getElementById('startColourPicker').value = hexColour;
                }
                if (data.endColour !== undefined) {
                    const hexColour = '#' + data.endColour.toString(16).padStart(6, '0').toUpperCase();
                    document.getElementById('endColour').value = hexColour.substring(1);
                    document.getElementById('endColourPicker').value = hexColour;
                }
                
                // Validate thresholds after loading
                validateThresholds();
                
                // Generate the nested structure
                generateCellSettings();
                
                // Load cell configs from nested structure (-1 means use global default, so leave empty)
                if (data.hemispheres && Array.isArray(data.hemispheres)) {
                    data.hemispheres.forEach((hemisphere, h) => {
                        if (hemisphere.panels && Array.isArray(hemisphere.panels)) {
                            hemisphere.panels.forEach((panel, p) => {
                                if (panel.cells && Array.isArray(panel.cells)) {
                                    panel.cells.forEach((cell, c) => {
                                        const pressVal = cell.pressPressure;
                                        const releaseVal = cell.releasePressure;
                                        const repressVal = cell.repressTime;
                                        
                                        const pressEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_press');
                                        const releaseEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_release');
                                        const repressEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_repress');
                                        
                                        if (pressEl) pressEl.value = (pressVal === -1 || pressVal === null || pressVal === undefined) ? '' : pressVal;
                                        if (releaseEl) releaseEl.value = (releaseVal === -1 || releaseVal === null || releaseVal === undefined) ? '' : releaseVal;
                                        if (repressEl) repressEl.value = (repressVal === -1 || repressVal === null || repressVal === undefined) ? '' : repressVal;
                                    });
                                }
                            });
                        }
                    });
                }
                
                showStatus('Configuration loaded successfully');
            } catch (error) {
                showStatus('Error loading configuration: ' + error.message, true);
            }
        }
        
        async function loadCellConfigs() {
            try {
                const response = await fetch('/api/config');
                const data = await response.json();
                
                // Load cell configs from nested structure
                if (data.hemispheres && Array.isArray(data.hemispheres)) {
                    data.hemispheres.forEach((hemisphere, h) => {
                        if (hemisphere.panels && Array.isArray(hemisphere.panels)) {
                            hemisphere.panels.forEach((panel, p) => {
                                if (panel.cells && Array.isArray(panel.cells)) {
                                    panel.cells.forEach((cell, c) => {
                                        const pressVal = cell.pressPressure;
                                        const releaseVal = cell.releasePressure;
                                        const repressVal = cell.repressTime;
                                        
                                        const pressEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_press');
                                        const releaseEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_release');
                                        const repressEl = document.getElementById('cell' + h + '_' + p + '_' + c + '_repress');
                                        
                                        if (pressEl) pressEl.value = (pressVal === -1 || pressVal === null || pressVal === undefined) ? '' : pressVal;
                                        if (releaseEl) releaseEl.value = (releaseVal === -1 || releaseVal === null || releaseVal === undefined) ? '' : releaseVal;
                                        if (repressEl) repressEl.value = (repressVal === -1 || repressVal === null || repressVal === undefined) ? '' : repressVal;
                                    });
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                console.error('Error loading cell configs:', error);
            }
        }
        
        document.getElementById('configForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Validate thresholds before submission
            validateThresholds();
            if (!document.getElementById('configForm').checkValidity()) {
                return;
            }
            
            const formData = {
                longTermAvgSamples: parseInt(document.getElementById('longTermAvgSamples').value),
                shortTermAvgSamples: parseInt(document.getElementById('shortTermAvgSamples').value),
                brightness: parseInt(document.getElementById('brightness').value),
                retriggerTime: parseInt(document.getElementById('retriggerTime').value),
                sampleTime: parseInt(document.getElementById('sampleTime').value),
                pressThreshold: parseInt(document.getElementById('pressThreshold').value),
                releaseThreshold: parseInt(document.getElementById('releaseThreshold').value),
                maxThreshold: parseInt(document.getElementById('maxThreshold').value),
                modeOverride: document.querySelector('input[name="modeOverride"]:checked') ? document.querySelector('input[name="modeOverride"]:checked').value : 'Base',
                modeOverrideEnabled: document.getElementById('modeOverrideEnabled').checked,
                i2cFrequency: parseInt(document.getElementById('i2cFrequency').value),
                startColour: parseInt(document.getElementById('startColour').value, 16),
                endColour: parseInt(document.getElementById('endColour').value, 16),
                hemispheres: []
            };
            
            // Build nested structure: 2 Hemispheres -> 4 Panels -> 8 Cells
            for (let h = 0; h < 2; h++) {
                const hemisphere = {
                    id: h,
                    panels: []
                };
                
                for (let p = 0; p < 4; p++) {
                    const panel = {
                        id: p,
                        cells: []
                    };
                    
                    for (let c = 0; c < 8; c++) {
                        const pressVal = document.getElementById('cell' + h + '_' + p + '_' + c + '_press').value;
                        const releaseVal = document.getElementById('cell' + h + '_' + p + '_' + c + '_release').value;
                        const repressVal = document.getElementById('cell' + h + '_' + p + '_' + c + '_repress').value;
                        
                        panel.cells.push({
                            id: c,
                            pressPressure: (pressVal === '' || pressVal === null) ? -1 : parseInt(pressVal),
                            releasePressure: (releaseVal === '' || releaseVal === null) ? -1 : parseInt(releaseVal),
                            repressTime: (repressVal === '' || repressVal === null) ? -1 : parseInt(repressVal)
                        });
                    }
                    
                    hemisphere.panels.push(panel);
                }
                
                formData.hemispheres.push(hemisphere);
            }
            
            try {
                const response = await fetch('/api/config', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                if (response.ok) {
                    showStatus('Configuration saved successfully!');
                } else {
                    showStatus('Error saving configuration', true);
                }
            } catch (error) {
                showStatus('Error saving configuration: ' + error.message, true);
            }
        });
        
        // Validate thresholds when they change
        document.getElementById('releaseThreshold').addEventListener('input', validateThresholds);
        document.getElementById('pressThreshold').addEventListener('input', validateThresholds);
        document.getElementById('maxThreshold').addEventListener('input', validateThresholds);
        
        // Handle Mode Override toggle switch
        function updateModeOverrideState(enabled) {
            const grid = document.getElementById('modeOverrideGrid');
            const radioButtons = grid.querySelectorAll('input[type="radio"]');
            
            if (enabled) {
                grid.classList.remove('disabled');
                radioButtons.forEach(radio => {
                    radio.disabled = false;
                });
            } else {
                grid.classList.add('disabled');
                radioButtons.forEach(radio => {
                    radio.disabled = true;
                });
            }
        }
        
        document.getElementById('modeOverrideEnabled').addEventListener('change', function() {
            updateModeOverrideState(this.checked);
        });
        
        // Initialize mode override state on page load
        updateModeOverrideState(document.getElementById('modeOverrideEnabled').checked);
        
        // Sync color picker with text field
        function syncColorPickerToText(pickerId, textId) {
            const picker = document.getElementById(pickerId);
            const text = document.getElementById(textId);
            picker.addEventListener('input', function() {
                text.value = this.value.substring(1).toUpperCase();
            });
        }
        
        // Sync text field with color picker
        function syncTextToColorPicker(textId, pickerId) {
            const text = document.getElementById(textId);
            const picker = document.getElementById(pickerId);
            text.addEventListener('input', function() {
                const value = this.value.toUpperCase();
                if (/^[0-9A-F]{6}$/.test(value)) {
                    picker.value = '#' + value;
                }
            });
        }
        
        // Initialize color picker sync
        syncColorPickerToText('startColourPicker', 'startColour');
        syncTextToColorPicker('startColour', 'startColourPicker');
        syncColorPickerToText('endColourPicker', 'endColour');
        syncTextToColorPicker('endColour', 'endColourPicker');
        
        // WiFi form submission
        document.getElementById('wifiForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const wifiData = {
                ssid: document.getElementById('wifiSSID').value,
                password: document.getElementById('wifiPassword').value
            };
            
            try {
                const response = await fetch('/api/wifi', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(wifiData)
                });
                
                if (response.ok) {
                    showStatus('WiFi settings saved successfully! Restart device to apply changes.');
                } else {
                    showStatus('Error saving WiFi settings', true);
                }
            } catch (error) {
                showStatus('Error saving WiFi settings: ' + error.message, true);
            }
        });
        
        async function loadWiFiConfig() {
            try {
                const response = await fetch('/api/wifi');
                const data = await response.json();
                
                document.getElementById('wifiSSID').value = data.ssid || '';
                document.getElementById('wifiPassword').value = data.password || '';
                
                showStatus('WiFi configuration loaded successfully');
            } catch (error) {
                showStatus('Error loading WiFi configuration: ' + error.message, true);
            }
        }
        
        // System diagnostics functions
        async function loadSystemInfo() {
            try {
                const response = await fetch('/api/diagnostics');
                const data = await response.json();
                
                document.getElementById('freeHeap').textContent = data.freeHeap || '-';
                document.getElementById('uptime').textContent = formatUptime(data.uptime || 0);
                document.getElementById('chipModel').textContent = data.chipModel || '-';
                document.getElementById('chipRevision').textContent = data.chipRevision || '-';
                document.getElementById('cpuFreq').textContent = data.cpuFreq || '-';
                document.getElementById('flashSize').textContent = data.flashSize || '-';
            } catch (error) {
                console.error('Error loading system info:', error);
            }
        }
        
        function formatUptime(seconds) {
            const days = Math.floor(seconds / 86400);
            const hours = Math.floor((seconds % 86400) / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = seconds % 60;
            
            if (days > 0) {
                return days + 'd ' + hours + 'h ' + minutes + 'm ' + secs + 's';
            } else if (hours > 0) {
                return hours + 'h ' + minutes + 'm ' + secs + 's';
            } else if (minutes > 0) {
                return minutes + 'm ' + secs + 's';
            } else {
                return secs + 's';
            }
        }
        
        let systemInfoInterval = null;
        function startSystemInfoUpdates() {
            if (systemInfoInterval) {
                clearInterval(systemInfoInterval);
            }
            loadSystemInfo();
            systemInfoInterval = setInterval(loadSystemInfo, 2000); // Update every 2 seconds
        }
        
        function stopSystemInfoUpdates() {
            if (systemInfoInterval) {
                clearInterval(systemInfoInterval);
                systemInfoInterval = null;
            }
        }
        
        // Firmware upload functions
        function handleFileSelect(files) {
            if (files.length > 0) {
                uploadFirmware(files[0]);
            }
        }
        
        function uploadFirmware(file) {
            if (!file.name.endsWith('.bin')) {
                showStatus('Please select a .bin firmware file', true);
                return;
            }
            
            const formData = new FormData();
            formData.append('firmware', file);
            
            // Show upload UI
            document.getElementById('uploadContent').style.display = 'none';
            document.getElementById('uploadProgress').style.display = 'block';
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('progressBar').style.width = '0%';
            document.getElementById('progressText').textContent = '0%';
            document.getElementById('uploadStatus').textContent = 'Preparing upload...';
            
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    document.getElementById('progressBar').style.width = percentComplete + '%';
                    document.getElementById('progressText').textContent = Math.round(percentComplete) + '%';
                }
            });
            
            xhr.addEventListener('load', function() {
                if (xhr.status === 200) {
                    document.getElementById('uploadStatus').textContent = 'Upload successful! Device will restart...';
                    document.getElementById('uploadStatus').style.color = '#27ae60';
                    showStatus('Firmware uploaded successfully! Device restarting...');
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                } else {
                    document.getElementById('uploadStatus').textContent = 'Upload failed: ' + xhr.responseText;
                    document.getElementById('uploadStatus').style.color = '#e74c3c';
                    showStatus('Firmware upload failed: ' + xhr.responseText, true);
                    resetUploadUI();
                }
            });
            
            xhr.addEventListener('error', function() {
                document.getElementById('uploadStatus').textContent = 'Upload error occurred';
                document.getElementById('uploadStatus').style.color = '#e74c3c';
                showStatus('Firmware upload error', true);
                resetUploadUI();
            });
            
            xhr.addEventListener('abort', function() {
                document.getElementById('uploadStatus').textContent = 'Upload cancelled';
                document.getElementById('uploadStatus').style.color = '#6c757d';
                resetUploadUI();
            });
            
            xhr.open('POST', '/update');
            xhr.send(formData);
        }
        
        function resetUploadUI() {
            setTimeout(() => {
                document.getElementById('uploadContent').style.display = 'block';
                document.getElementById('uploadProgress').style.display = 'none';
                document.getElementById('firmwareFile').value = '';
            }, 2000);
        }
        
        // Sub-controller firmware upload functions
        function handleSubFileSelect(files) {
            if (files.length > 0) {
                uploadSubFirmware(files[0]);
            }
        }
        
        function uploadSubFirmware(file) {
            if (!file.name.endsWith('.bin')) {
                showStatus('Please select a .bin firmware file', true);
                return;
            }
            
            const formData = new FormData();
            formData.append('firmware', file);
            
            // Show upload UI
            document.getElementById('subUploadContent').style.display = 'none';
            document.getElementById('subUploadProgress').style.display = 'block';
            document.getElementById('subFileName').textContent = file.name;
            document.getElementById('subProgressBar').style.width = '0%';
            document.getElementById('subProgressText').textContent = '0%';
            document.getElementById('subUploadStatus').textContent = 'Preparing upload...';
            
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;
                    document.getElementById('subProgressBar').style.width = percentComplete + '%';
                    document.getElementById('subProgressText').textContent = Math.round(percentComplete) + '%';
                }
            });
            
            xhr.addEventListener('load', function() {
                if (xhr.status === 200) {
                    document.getElementById('subUploadStatus').textContent = 'Upload successful! Updating sub-controller...';
                    document.getElementById('subUploadStatus').style.color = '#27ae60';
                    showStatus('Sub-controller firmware uploaded successfully! Update in progress...');
                    setTimeout(() => {
                        resetSubUploadUI();
                    }, 3000);
                } else {
                    document.getElementById('subUploadStatus').textContent = 'Upload failed: ' + xhr.responseText;
                    document.getElementById('subUploadStatus').style.color = '#e74c3c';
                    showStatus('Sub-controller firmware upload failed: ' + xhr.responseText, true);
                    resetSubUploadUI();
                }
            });
            
            xhr.addEventListener('error', function() {
                document.getElementById('subUploadStatus').textContent = 'Upload error occurred';
                document.getElementById('subUploadStatus').style.color = '#e74c3c';
                showStatus('Sub-controller firmware upload error', true);
                resetSubUploadUI();
            });
            
            xhr.addEventListener('abort', function() {
                document.getElementById('subUploadStatus').textContent = 'Upload cancelled';
                document.getElementById('subUploadStatus').style.color = '#6c757d';
                resetSubUploadUI();
            });
            
            xhr.open('POST', '/update-sub');
            xhr.send(formData);
        }
        
        function resetSubUploadUI() {
            setTimeout(() => {
                document.getElementById('subUploadContent').style.display = 'block';
                document.getElementById('subUploadProgress').style.display = 'none';
                document.getElementById('subFirmwareFile').value = '';
            }, 2000);
        }
        
        // Drag and drop handlers for main firmware
        const uploadArea = document.getElementById('uploadArea');
        
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            uploadArea.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                uploadFirmware(files[0]);
            }
        });
        
        // Drag and drop handlers for sub-controller firmware
        const subUploadArea = document.getElementById('subUploadArea');
        
        subUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            subUploadArea.classList.add('drag-over');
        });
        
        subUploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            subUploadArea.classList.remove('drag-over');
        });
        
        subUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            subUploadArea.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                uploadSubFirmware(files[0]);
            }
        });
        
        // Load config on page load
        window.addEventListener('load', () => {
            loadConfig();
            loadWiFiConfig();
            // Generate cell settings structure on load
            generateCellSettings();
        });</script>)HTML");
}

// API endpoint: POST /api/wifi
void handlePostWiFi() {
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    
    DynamicJsonDocument doc(256);
    DeserializationError error = deserializeJson(doc, body);
    
    if (error) {
      server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
      return;
    }
    
    if (doc.containsKey("ssid")) {
      wifiConfig.ssid = doc["ssid"].as<String>();
      if (wifiConfig.ssid.length() > 32) wifiConfig.ssid = wifiConfig.ssid.substring(0, 32);
    }
    
    if (doc.containsKey("password")) {
      wifiConfig.password = doc["password"].as<String>();
      if (wifiConfig.password.length() > 63) wifiConfig.password = wifiConfig.password.substring(0, 63);
      if (wifiConfig.password.length() < 8) {
        server.send(400, "application/json", "{\"error\":\"Password must be at least 8 characters\"}");
        return;
      }
    }
    
    // Save to preferences
    saveWiFiConfig();
    
    server.send(200, "application/json", "{\"status\":\"ok\"}");
  } else {
    server.send(400, "application/json", "{\"error\":\"No data\"}");
  }
}

// Handle 404
void handleNotFound() {
  server.send(404, "text/plain", "Not Found");
}


void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("Wayfinding Moon ESP Controller");
  Serial.println("Initializing...");
  
  // Initialize default cell configs
  initDefaultCellConfigs();
  
  // Load saved configuration
  loadConfig();
  
  // Setup WiFi Access Point (use saved config)
  Serial.print("Setting up WiFi Access Point: ");
  Serial.println(wifiConfig.ssid);
  
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(wifiConfig.ssid.c_str(), wifiConfig.password.c_str());

  
  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);
  
  // Setup web server routes
  server.on("/", handleRoot);
  server.on("/api/config", HTTP_GET, handleGetConfig);
  server.on("/api/config", HTTP_POST, handlePostConfig);
  server.on("/api/wifi", HTTP_GET, handleGetWiFi);
  server.on("/api/wifi", HTTP_POST, handlePostWiFi);
  server.on("/api/diagnostics", HTTP_GET, handleGetDiagnostics);
  server.on("/update", HTTP_POST, handleUpdatePage, handleUpdate);
  server.on("/update-sub", HTTP_POST, handleSubUpdatePage, handleSubUpdate);
  server.onNotFound(handleNotFound);
  
  // Start web server
  server.begin();
  Serial.println("Web server started!");
  
  // Start WebSocket server
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);
  Serial.println("WebSocket server started on port 81!");
  
  Serial.println("Connect to WiFi: " + wifiConfig.ssid);
  Serial.println("Password: " + wifiConfig.password);
  Serial.println("Open browser to: http://" + IP.toString());
  
  // Send initial console message
  consolePrintln("=== Wayfinding Moon ESP Controller ===");
  consolePrintln("System initialized successfully");
  consolePrint("WiFi AP: ");
  consolePrintln(wifiConfig.ssid);
  consolePrint("IP Address: ");
  consolePrintln(IP.toString());

  MainControllerSetup();

}




void loop() {
  server.handleClient();
  webSocket.loop();  // Handle WebSocket events
  

  MainControllerLoop();

  delay(1);
}

