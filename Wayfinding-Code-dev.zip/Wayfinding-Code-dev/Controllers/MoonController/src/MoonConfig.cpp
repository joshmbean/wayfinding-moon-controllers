#include <Arduino.h>
#include <Preferences.h>
#include <Wire.h>

#include "MoonConfig.h"

#define I2C_SDA_PIN  33
#define I2C_SCL_PIN  32
#define I2C2_SDA_PIN  13
#define I2C2_SCL_PIN  14

// Preferences for persistent storage
Preferences preferences;

// Default configuration
Config globalConfig = {
  .longTermAvgSamples = 1000,
  .shortTermAvgSamples = 100,
  .brightness = 50,
  .retriggerTime = 500,
  .sampleTime = 10,
  .pressThreshold = 150,
  .releaseThreshold = 50,
  .maxThreshold = 200,
  .modeUser = "Base",
  .modeOverride = "Base",
  .modeOverrideEnabled = false,
  .i2cFrequency = 100,
  .startColour = 0xFF0000,          // Red (default)
  .endColour = 0x0000FF,            // Blue (default)
  .globalDefaultPressPressure = 100,
  .globalDefaultReleasePressure = 50,
  .globalDefaultRepressTime = 500
};

WiFiConfig wifiConfig = {
  .ssid = "WayfindingMoon",
  .password = "wayfinding123"
};

CellConfig cellConfigs[NUM_HEMISPHERES][NUM_PANELS_PER_HEMISPHERE][NUM_CELLS_PER_PANEL];

// Initialize default cell configs (use -1 to indicate "use global default")
void initDefaultCellConfigs() {
  for (int h = 0; h < NUM_HEMISPHERES; h++) {
    for (int p = 0; p < NUM_PANELS_PER_HEMISPHERE; p++) {
      for (int c = 0; c < NUM_CELLS_PER_PANEL; c++) {
        cellConfigs[h][p][c].pressPressure = -1;
        cellConfigs[h][p][c].releasePressure = -1;
        cellConfigs[h][p][c].repressTime = -1;
      }
    }
  }
}

// Get effective cell config value (returns global default if cell value is -1)
int getEffectivePressPressure(int hemisphere, int panel, int cell) {
  if (cellConfigs[hemisphere][panel][cell].pressPressure == -1) {
    return globalConfig.globalDefaultPressPressure;
  }
  return cellConfigs[hemisphere][panel][cell].pressPressure;
}

int getEffectiveReleasePressure(int hemisphere, int panel, int cell) {
  if (cellConfigs[hemisphere][panel][cell].releasePressure == -1) {
    return globalConfig.globalDefaultReleasePressure;
  }
  return cellConfigs[hemisphere][panel][cell].releasePressure;
}

int getEffectiveRepressTime(int hemisphere, int panel, int cell) {
  if (cellConfigs[hemisphere][panel][cell].repressTime == -1) {
    return globalConfig.globalDefaultRepressTime;
  }
  return cellConfigs[hemisphere][panel][cell].repressTime;
}

// Load configuration from preferences
void loadConfig() {
  preferences.begin("config", true); // read-only mode
  
  globalConfig.longTermAvgSamples = preferences.getUShort("longTermAvg", 1000);
  globalConfig.shortTermAvgSamples = preferences.getUShort("shortTermAvg", 100);
  globalConfig.brightness = preferences.getUChar("brightness", 50);
  globalConfig.retriggerTime = preferences.getUShort("retriggerTime", 500);
  globalConfig.sampleTime = preferences.getUShort("sampleTime", 10);
  globalConfig.pressThreshold = preferences.getUChar("pressThreshold", 150);
  globalConfig.releaseThreshold = preferences.getUChar("releaseThreshold", 50);
  globalConfig.maxThreshold = preferences.getUChar("maxThreshold", 200);
  globalConfig.modeOverride = preferences.getString("modeOverride", "Base");
  globalConfig.modeOverrideEnabled = preferences.getBool("modeOverrideEnabled", false);
  globalConfig.i2cFrequency = preferences.getUChar("i2cFreq", 100);
  globalConfig.startColour = preferences.getUInt("startColour", 0xFF0000);
  globalConfig.endColour = preferences.getUInt("endColour", 0x0000FF);
  // Legacy cell defaults
  globalConfig.globalDefaultPressPressure = preferences.getInt("globalPress", 100);
  globalConfig.globalDefaultReleasePressure = preferences.getInt("globalRelease", 50);
  globalConfig.globalDefaultRepressTime = preferences.getInt("globalRepress", 500);
  
  // Load cell configs (-1 means use global default)
  // Structure: h<hemisphere>_p<panel>_c<cell>_<field>
  for (int h = 0; h < NUM_HEMISPHERES; h++) {
    for (int p = 0; p < NUM_PANELS_PER_HEMISPHERE; p++) {
      for (int c = 0; c < NUM_CELLS_PER_PANEL; c++) {
        String key = "h" + String(h) + "_p" + String(p) + "_c" + String(c);
        // Use -2 as default to detect if key exists, then use -1 if not found
        int pressVal = preferences.getInt((key + "_press").c_str(), -2);
        int releaseVal = preferences.getInt((key + "_release").c_str(), -2);
        int repressVal = preferences.getInt((key + "_repress").c_str(), -2);
        
        cellConfigs[h][p][c].pressPressure = (pressVal == -2) ? -1 : pressVal;
        cellConfigs[h][p][c].releasePressure = (releaseVal == -2) ? -1 : releaseVal;
        cellConfigs[h][p][c].repressTime = (repressVal == -2) ? -1 : repressVal;
      }
    }
  }
  
  preferences.end();
  
  // Load WiFi config
  preferences.begin("wifi", true);
  wifiConfig.ssid = preferences.getString("ssid", "WayfindingMoon");
  wifiConfig.password = preferences.getString("password", "wayfinding123");
  preferences.end();
}

// Save configuration to preferences
void saveConfig() {
  preferences.begin("config", false); // read-write mode
  
  preferences.putUShort("longTermAvg", globalConfig.longTermAvgSamples);
  preferences.putUShort("shortTermAvg", globalConfig.shortTermAvgSamples);
  preferences.putUChar("brightness", globalConfig.brightness);
  preferences.putUShort("retriggerTime", globalConfig.retriggerTime);
  preferences.putUShort("sampleTime", globalConfig.sampleTime);
  preferences.putUChar("pressThreshold", globalConfig.pressThreshold);
  preferences.putUChar("releaseThreshold", globalConfig.releaseThreshold);
  preferences.putUChar("maxThreshold", globalConfig.maxThreshold);
  preferences.putString("modeOverride", globalConfig.modeOverride);
  preferences.putBool("modeOverrideEnabled", globalConfig.modeOverrideEnabled);
  preferences.putUChar("i2cFreq", globalConfig.i2cFrequency);
  preferences.putUInt("startColour", globalConfig.startColour);
  preferences.putUInt("endColour", globalConfig.endColour);
  // Legacy cell defaults
  preferences.putInt("globalPress", globalConfig.globalDefaultPressPressure);
  preferences.putInt("globalRelease", globalConfig.globalDefaultReleasePressure);
  preferences.putInt("globalRepress", globalConfig.globalDefaultRepressTime);
  
  // Save cell configs
  // Structure: h<hemisphere>_p<panel>_c<cell>_<field>
  for (int h = 0; h < NUM_HEMISPHERES; h++) {
    for (int p = 0; p < NUM_PANELS_PER_HEMISPHERE; p++) {
      for (int c = 0; c < NUM_CELLS_PER_PANEL; c++) {
        String key = "h" + String(h) + "_p" + String(p) + "_c" + String(c);
        preferences.putInt((key + "_press").c_str(), cellConfigs[h][p][c].pressPressure);
        preferences.putInt((key + "_release").c_str(), cellConfigs[h][p][c].releasePressure);
        preferences.putInt((key + "_repress").c_str(), cellConfigs[h][p][c].repressTime);
      }
    }
  }
  
  preferences.end();
  
  // consolePrintf("Intializing I2C at %dHz", globalConfig.i2cFrequency * 1000);
  //I2C initilization
  Wire.end();
  Wire1.end();
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, globalConfig.i2cFrequency * 1000);
  Wire1.begin(I2C2_SDA_PIN, I2C2_SCL_PIN, globalConfig.i2cFrequency * 1000);
}

// Save WiFi configuration
void saveWiFiConfig() {
  preferences.begin("wifi", false);
  preferences.putString("ssid", wifiConfig.ssid);
  preferences.putString("password", wifiConfig.password);
  preferences.end();
}