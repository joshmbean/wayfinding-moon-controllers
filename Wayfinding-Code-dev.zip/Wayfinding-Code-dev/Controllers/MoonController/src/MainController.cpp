#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <Wire.h>
#include <esp_now.h>
#include <WiFi.h>
#include "esp_now_midi.h"

#include "MoonConfig.h"
#include "commands.h"


#define CMD_SET_MODE_PRESSURE 0x10U
#define CMD_SET_MODE_MUSIC 0x11U
#define CMD_SET_MODE_SIMON_DISPLAY 0x12U
#define CMD_SET_MODE_SIMON_REACT 0x13U
#define CMD_SET_MODE_CALIBRATION 0x14U
#define CMD_SET_MODE_TEST 0x15U
#define CMD_SET_MODE_MOTH  0x16U
#define CMD_SET_MODE_COLOUR 0x17U
#define CMD_SET_MODE_STANDBY 0x18U
#define CMD_SET_MODE_FLASH   0x19U

// ======== Is2C ========
#define I2C_FREQ  25000
#define I2C_SDA_PIN  33
#define I2C_SCL_PIN  32
#define I2C2_SDA_PIN  13
#define I2C2_SCL_PIN  14


//==== MODES =======
#define MODE_BASE 0
#define MODE_MOTH 1
#define MODE_MUSIC 2
#define MODE_COLOUR 3
#define MODE_SIMON_DISPLAY 4
#define MODE_SIMON_REACT 5
#define MODE_STANDBY 6
uint8_t mode = MODE_STANDBY;

#define MODE_COLOUR_QTY 7
#define MODE_MUSIC_DEFAULT_VALUE 50
#define MODE_MOTH_DEFAULT_VALUE 50
#define MODE_MOTH_SIMON_FLASH_TIME 500


#define DATA_COLOUR 1
#define DATA_MODE 2
#define DATA_CONFIG 3
#define DATA_REQUEST 4
#define DATA_CONFIG_ID 10

#define REQUEST_PRESSURE 0
#define REQUEST_PRESS_COUNT 1

#define HEMI_QTY 2
#define PANE_QTY 5
#define CELL_QTY 8
bool debug = true;

uint8_t cell_readings[2][5][8]; // array holding cell readings

// Forward declaration for console functions (defined in main file)
extern void consolePrint(const String& message);
extern void consolePrintln(const String& message);
extern void consolePrintf(const char *fmt, ...);
extern esp_now_midi ESP_NOW_MIDI;

// Prototypes
uint8_t cellToAddress(uint8_t hemisphere, uint8_t panel, uint8_t cell);

// Global Variables
extern Config globalConfig;

uint8_t note_scale[8] = {48,50,52,54,55,57,59,60};
// uint8_t panel_notes[8] = {6,5,4,0,1,7,3,2}
uint8_t panel_notes[8] = { 3, 4,7,6 ,3 ,2 ,1 ,5 };
uint8_t colour_note_index[16] {0,1,0,2,0,3,0,4,0,5,0,6,0,7,0,0};


uint8_t panel_modes[2][5] = { { MODE_BASE , MODE_BASE , MODE_BASE , MODE_COLOUR, MODE_COLOUR },
                              { MODE_BASE , MODE_BASE , MODE_COLOUR   , MODE_COLOUR, MODE_COLOUR }};


// ======== CELL CONFIG VARIABLES ========
#define CFG_QTY 8  //Number of configuration variables

#define CFG_LT_AVG 0
#define CFG_ST_AVG 1
#define CFG_BRIGHT 2
#define CFG_RETRIG 3
#define CFG_PRESS_THR 4
#define CFG_RELEASE_THR 5
#define CFG_MAX_THR 6
#define CFG_SAMPLE_TIME 7

uint8_t config[CFG_QTY] = {
  100,     //Long term average samples(stored as 1/10th of its value)
  10,      //Short term average samples
  255,     //Global LED brightness
  10,      //Retrigger time (stored as 1/10th of its value)
  20,      //pressre threshold (.08*255)
  13,  //pressure release threshold (.05*255)
  179,   //maximum pressure threshold (.7*255)
  5        //sampling time
};

//===============CELL ARRAY VARIABLES====================
#define ALL_CELL_QTY HEMI_QTY*PANE_QTY*CELL_QTY

uint8_t pressure[ALL_CELL_QTY];
uint8_t press_count[ALL_CELL_QTY];
uint8_t address[ALL_CELL_QTY];
uint32_t colour[ALL_CELL_QTY];

// extern Config globalConfig;
// Forward declaration for console functions (defined in main file)
extern void consolePrint(const String& message);
extern void consolePrintln(const String& message);
extern void consolePrintf(char *fmt, ...);

void inline debug_println (const char * text) {
  if (debug) { Serial.println(text); }
}

void inline debug_println (const String text) {
  if (debug) { Serial.println(text); }
}

void inline debug_print (const char * text) {
  if (debug) { Serial.print(text); }
}


// Declare Simon.
void playSimon();
TwoWire* getBus(uint8_t);

// Just initializing this for the ColorHSV function.
Adafruit_NeoPixel strip = Adafruit_NeoPixel(3, 3, NEO_GRB + NEO_KHZ800);

// 


union colourUnion  {
  uint32_t col32;
  uint8_t col8[4];
};


void I2C_send_col(uint8_t hemisphere, uint8_t panel, uint8_t cell, uint8_t col){
  consolePrintf("sending 0x%x to H%dP%dC%d ... ", col, hemisphere, panel, cell);
  uint8_t addr = cellToAddress(hemisphere,panel,cell);
  
  TwoWire* WirePtr = getBus(hemisphere);
  // uint8_t address =addr&0b01111111;
  (*WirePtr).beginTransmission(addr);
  consolePrintf("address is 0x%x", addr);
  (*WirePtr).write(col);
  // (*WirePtr).write(colU.col8[2]); 
  // (*WirePtr).write(colU.col8[3]);
  // (*WirePtr).write(colU.col8[4]);
  uint8_t error = Wire.endTransmission(true);
  if (error) {
    consolePrintf("I2C Error: %u at  %u \n",error, address);
  }
  consolePrintln("Sent");
  delay(5);
}

void I2C_send_colour(uint8_t hemisphere, uint8_t panel, uint8_t cell, uint8_t colour) {
  TwoWire* WirePtr = getBus(hemisphere);
  (*WirePtr).beginTransmission(cellToAddress(hemisphere, panel, cell));
  (*WirePtr).write((uint8_t)0x50U);
  (*WirePtr).endTransmission(true);

  return;
}

void I2C_send_command(uint8_t hemisphere, uint8_t panel, uint8_t cell, uint8_t command) {
  TwoWire* WirePtr = getBus(hemisphere);
  (*WirePtr).beginTransmission(cellToAddress(hemisphere, panel, cell));
  (*WirePtr).write(command);
  (*WirePtr).endTransmission(true);

  return;
}

// void I2C_send_col(uint8_t* cell, uint32_t col){
//   I2C_send_col(cell[0],cell[1],cell[2],col);
// }

// void I2C_send_col(uint8_t addr, uint32_t col){
//   union colourUnion colU;
//   colU.col32 = col;
//   consolePrintf("sending 0x%x to 0o%o \n", col, addr);
//   TwoWire* WirePtr = &Wire1;
//   // uint8_t address =addr&0b01111111;
  
//   Wire1.beginTransmission(addr);
//   Wire1.write(CMD_INST_COLOUR);
//   // Wire1.write(colU.col8[0]); 
//   // Wire1.write(colU.col8[1]);
//   // Wire1.write(colU.col8[2]);
//   uint8_t error = Wire1.endTransmission(true);
//   if (error) {
//     consolePrintf("I2C Error: %u at  %u \n",error, addr);
//   }
// }

// void I2C_send_mode(uint8_t hemisphere, uint8_t panel, uint8_t cell, uint8_t mode){
//   if (hemisphere == 2) {
//     I2C_send_mode(0, panel, cell, mode);
//     I2C_send_mode(1, panel, cell, mode);
//     return;
//   }
//   TwoWire* WirePtr = getBus(hemisphere);
//   uint8_t address = cellToAddress(hemisphere, panel, cell);

//     (*WirePtr).beginTransmission(address);
//     (*WirePtr).write(mode);
//     (*WirePtr).endTransmission(true);
// }


uint8_t mode_string_to_cmd (String mode) {
  if (mode == "Base") { return CMD_SET_MODE_PRESSURE; }
  if (mode == "Moth") { return CMD_SET_MODE_MOTH; }
  if (mode == "Music") { return CMD_SET_MODE_MUSIC; }
  if (mode == "Colour") { return CMD_SET_MODE_COLOUR; }
  if (mode == "Simon") { return CMD_SET_MODE_SIMON_DISPLAY; }
  if (mode == "Standby") { return CMD_SET_MODE_STANDBY; }
  if (mode == "Debug") { return CMD_SET_MODE_CALIBRATION; }
  if (mode == "Flash") { return CMD_SET_MODE_FLASH; }

  return 0;
}
// Base, Moth, Music, Colour, Simon, Standby, Debug, Flash
void I2C_send_mode(TwoWire* WirePtr, uint8_t addr, String mode){ 

  (*WirePtr).beginTransmission(addr);
  (*WirePtr).write(mode_string_to_cmd(mode));
  (*WirePtr).endTransmission(true);

}

//MIDI STUFF


static inline void serialMidiOn(uint8_t channel, uint8_t note, uint8_t velocity)
{
   // MIDI channels are 1–16, encoded as 0–15 in the message
   Serial.write(0x90 | ((channel - 1) & 0x0F));
   Serial.write(note);
   Serial.write(velocity);
}

// Send raw MIDI Note Off
static inline void serialMidiOff(uint8_t channel, uint8_t note)
{
   Serial.write(0x80 | ((channel - 1) & 0x0F));
   Serial.write(note);
   Serial.write(0x00);
}

static inline void serialMidiPressure(uint8_t channel, uint8_t note, uint8_t pressure)
{
   // MIDI channels are 1–16, encoded as 0–15 in the message
   Serial.write(0xA0 | ((channel - 1) & 0x0F));
   Serial.write(note);
   Serial.write(pressure);
}

void ESPNowMidiOn (uint8_t note, uint8_t chanel) {
  esp_err_t result = ESP_NOW_MIDI.sendNoteOn(note, 127, chanel);

  if (result != ESP_OK) {
    debug_println("sendON: Error sending the data");
  }
}

uint8_t getChanel (uint8_t hemisphere, uint8_t panel) {
  return (hemisphere*5 + panel );
}

uint8_t getCellNote(uint8_t cell) {
  uint8_t index = panel_notes[cell];
  return note_scale[index];
}

uint8_t getColourNote(uint8_t colour) {
  uint8_t index = colour_note_index[colour] & 0x7F;
  return note_scale[index];

}

void ESPNowMidiOff (uint8_t note, uint8_t chanel) {
  esp_err_t result = ESP_NOW_MIDI.sendNoteOff(note, 0, chanel);

  if (result != ESP_OK) {
    debug_println("sendOff: Error sending the data");
  }
}

void ESPNowMidiPressure(uint8_t note, uint8_t pressure, uint8_t chanel) {
  esp_err_t result = ESP_NOW_MIDI.sendAfterTouchPoly(note, pressure, chanel);

  if (result != ESP_OK) {
    debug_println("sendPressure: Error sending the data"); 
  }

}

uint8_t prev_readings[2][5][8];
// uint8_t cell_readings[2][5][8];


void sendCellMidi(uint8_t hemisphere, uint8_t panel,uint8_t cell) {
  uint8_t prev_reading = prev_readings[hemisphere][panel-1][cell];
  uint8_t cell_reading = cell_readings[hemisphere][panel-1][cell];

  if (cell_reading == prev_reading ) {
    return;
  }
  bool cell_mode = cell_reading >>7; //if MSB is 1, cell is in colour mode
  uint8_t chanel = getChanel(hemisphere,panel);

  if (cell_mode) {
    serialMidiOn(chanel, getColourNote(cell_reading), 127);
    //perhaps add delay or interrupt timer
    serialMidiOff(chanel, getColourNote(cell_reading));
  } else {
    uint8_t note = getCellNote(cell);
    if (cell_reading == 0 ) {
      serialMidiOff (chanel,note);
      return;
    }
    if (prev_reading == 0 ) {
      serialMidiOn(chanel, note, 127);
    }
    serialMidiPressure(chanel,note,cell_reading);
  }
}

void sendAllMidi (){
  for(int hemisphere = 0; hemisphere<HEMI_QTY; hemisphere++){
    for(int panel = 1; panel<=PANE_QTY; panel++){
      for (int cell = 0; cell<CELL_QTY; cell++ ){
        sendCellMidi(hemisphere,panel,cell);
        prev_readings[hemisphere][panel][cell] = cell_readings[hemisphere][panel][cell];
      }
    }
  }
}



void I2C_send_config(TwoWire* WirePtr, uint8_t addr){
  (*WirePtr).beginTransmission(addr);
  (*WirePtr).write(DATA_CONFIG);
  (*WirePtr).write(config,CFG_QTY);
  (*WirePtr).endTransmission(true);
}

// void I2C_send_request(TwoWire* WirePtr, uint8_t addr,uint8_t req){
//   (*WirePtr).beginTransmission(addr);
//   (*WirePtr).write(DATA_REQUEST);
//   (*WirePtr).write(req);
//   (*WirePtr).endTransmission(true);
// }

#define REQUEST_BYTES 3
uint8_t I2C_request ( uint8_t hemisphere, uint8_t panel, uint8_t cell){
  // consolePrintf("Requesting Data From H%dP%dC%d ... ",hemisphere,panel,cell);
  TwoWire* WirePtr = getBus(hemisphere);
  uint8_t address = cellToAddress(hemisphere, panel, cell);
  // I2C_send_request(WirePtr, addr,data);
  uint8_t bytesReceived = (*WirePtr).requestFrom(address, size_t (REQUEST_BYTES),false);
  uint8_t val;

  for (int i=0; i<REQUEST_BYTES; i++){
    if((*WirePtr).available()) {
      val = (*WirePtr).read();
      if(val!=255){
        // consolePrintf("0x%x\n",val);
        return val;
      }
    } else {
      break;
    }
  }
  // consolePrintf("No valid bytes received from %u \n",address);

  return 0;
}

// uint8_t I2C_request ( uint8_t* cell){
//   return I2C_request ( cell[0], cell[1], cell[2]);
// }

// there has been a change in the callback signature with esp32 board version 3.3.0, hence this is here for backwards compatibility
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 3, 0)
void customOnDataSent(const wifi_tx_info_t* info, esp_now_send_status_t status) {
  debug_println(status == ESP_NOW_SEND_SUCCESS ? "Success" : "Failure");
}
#else
void customOnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  debug_println(status == ESP_NOW_SEND_SUCCESS ? "Success" : "Failure");
}
#endif

uint8_t macAddressMoth[6]  =  {0x12, 0x34, 0x56, 0x78, 0x9A, 0x00};
uint8_t macAddressMoon[6]  =  {0x12, 0x34, 0x56, 0x78, 0x9A, 0x01};

esp_now_midi ESP_NOW_MIDI;

void espNowSetup() {
  esp_wifi_set_mac(WIFI_IF_STA, macAddressMoon);

  ESP_NOW_MIDI.setup(macAddressMoth, customOnDataSent);

}


//********** ORBIT MODE STUFF *********
#define ORBIT_PERIOD 60000
#define ORBIT_COLOUR CMD_COLSOLD_15

const float cell_longatude[8] = { 0.0 , 338.5 , 348.6 , 11.4 , 21.5 , 360.0 , 36.0 , 36.0 };
const float cell_latatude[8] = { 26.6 , 30.9 , 10.5 , 10.5 , 30.9 , 45.9 , 52.6 , 10.8 };
const float panel_longatude_offset = 72.0;
const float panel_latatude_offset = 0;
const float hemisphere_longatude_offset = 36.0;
const float hemisphere_latatude_offset = 0;
const float hemisphere_longatude_multiplier = 1;
const float hemisphere_latatude_multiplier = -1;

float longatude[HEMI_QTY][PANE_QTY][CELL_QTY];
float latatude[HEMI_QTY][PANE_QTY][CELL_QTY];
bool cell_on[HEMI_QTY][PANE_QTY][CELL_QTY];
bool coordinates_calculated = false;

void calculate_cell_longatudes(){
  float multiplier = 1;
  for (int hemisphere = 0; hemisphere <HEMI_QTY; hemisphere++) {
    if (hemisphere >0) {
      multiplier = hemisphere * hemisphere_longatude_multiplier;
    }
    for(int panel = 1; panel <=PANE_QTY; panel++){
      for(int cell = 0; cell <CELL_QTY; cell++) {
        longatude[hemisphere][panel-1][cell] = multiplier*(hemisphere*hemisphere_longatude_offset+panel*panel_longatude_offset+cell_longatude[cell]);
        if (longatude[hemisphere][panel-1][cell] > 360) {
          longatude[hemisphere][panel-1][cell]-=360;
        }
      }
    }
  }
}


void calculate_cell_latatudes(){
  float multiplier = 1;
  for (int hemisphere = 0; hemisphere <HEMI_QTY; hemisphere++) {
    if (hemisphere >0) {
      multiplier = hemisphere * hemisphere_latatude_multiplier;
    }
    for(int panel = 1; panel <=PANE_QTY; panel++){
      for(int cell = 0; cell <CELL_QTY; cell++) {
        latatude[hemisphere][panel-1][cell] = multiplier*(hemisphere*hemisphere_latatude_offset+panel*panel_latatude_offset+cell_latatude[cell]);
        if (latatude[hemisphere][panel-1][cell] > 360) {
          latatude[hemisphere][panel-1][cell]-=360;
        }
      }
    }
  }
}


void orbit(){
  if(!coordinates_calculated) { //if the coordinates haven't been calculated yet -> calculate them
    calculate_cell_latatudes();
    calculate_cell_longatudes();
    coordinates_calculated = true;
  }
  float central_longatude = millis()%ORBIT_PERIOD * 360.0/ORBIT_PERIOD;             //find the central longatude of the sunny side
  Serial.printf("Central Longatude: %f \n", central_longatude);
  float cell_longatude;
  int face_angle;                                                               //the angle from the cell to the central longatude
  for (int hemisphere = 0; hemisphere <HEMI_QTY; hemisphere++) {                           //loop through hemispheres
    for(int panel = 1; panel <=PANE_QTY; panel++){                                         //loop through panels
      for(int cell = 0; cell <CELL_QTY; cell++) {                                          //loop through cells
        cell_longatude = longatude[hemisphere][panel-1][cell];                       //get longatude of current cell
        face_angle = abs((int(central_longatude-cell_longatude-180)%360+360)%360-180);      // calculate absolute angle between cell and central longatude
        if(face_angle <= 90) {                                                      //if this angle is less than 90 deg (it is on the sunny side)
          if(!cell_on[hemisphere][panel-1][cell]){                                  //if this cell is currently off
            cell_on[hemisphere][panel-1][cell] = true;                              //set it to on
            Serial.printf("H%dP%dC%d: ON - %d\n",hemisphere, panel, cell,face_angle);
          }
        } else {                                                                    //otherwise, the cell is on the dark side
          if(cell_on[hemisphere][panel-1][cell]){                                   //if this cell is currently turned on
            cell_on[hemisphere][panel-1][cell] = false;                              //set it to off
            Serial.printf("H%dP%dC%d: OFF - %d\n",hemisphere, panel, cell,face_angle);
          }
        }
      }
    }
  }
}

void flash() {
uint8_t reading;
  for (int hemisphere =0; hemisphere < HEMI_QTY; hemisphere++) {
    for (int panel = 1; panel <=PANE_QTY; panel++) {
      for (int cell = 0; cell <CELL_QTY; cell++) {
      reading = cell_readings[hemisphere][panel-1][cell];
        if(reading > 0) {
          // consolePrintf ("H%dP%dC%d pressed \n", hemisphere1, panel1, cell1);

          I2C_send_colour(hemisphere, panel, cell, (uint8_t) 0x50U);

        }
      }
    }
  }
}

String modeToString(uint8_t modeInt) {
  // convert mode integer to equiv mode string
  switch (modeInt) {
    case MODE_BASE:
      return "Base";
    case MODE_COLOUR:
      return "Colour";
    case MODE_MOTH:
      return "Moth";
    case MODE_MUSIC:
      return "Music";
    default:
      return globalConfig.modeUser;
  }
}


void hybrid_mode(){
  debug_println("HEY MUSIC HERE!!!!!!!!!!!!!!!!");
  // special handling to handle "Hybrid Mode"
  // for (uint8_t i = 0; i < 3; i++) {
    // Send these modes three times to minimize chance of missed cells
    for (uint8_t hemNum = 0; hemNum < HEMI_QTY; hemNum++) {
      debug_println("HEY MUSIC HERE????????????????");
      // per hemisphere
      for (uint8_t panelNum = 1; panelNum <= PANE_QTY; panelNum++) {
        debug_println("HEY MUSIC HERE#############");
        // per panel
        for (uint8_t cellNum = 0; cellNum < CELL_QTY; cellNum++) {
          debug_println("HEY MUSIC HERE*****************");
          // per cell
          String modeStr = modeToString(panel_modes[hemNum][panelNum]);
          if (hemNum) {
            I2C_send_mode(&Wire1, cellToAddress(hemNum, panelNum, cellNum), modeStr); // set mode for this cell in hemisphere 1
          } else {
            I2C_send_mode(&Wire, cellToAddress(hemNum, panelNum, cellNum), modeStr); // set mode for this cell in hemisphere 0
          }
          delay(5);
        }
        
      }
    }
  // }
}


const uint32_t sweeptime = 10;
bool poll_cells() {
  static uint32_t lastsweep = 0;
  if (millis()<(lastsweep+sweeptime)) { return false;}
  lastsweep = millis();
  uint8_t reading;
  consolePrintln("Polling Cells...");
  for (int hemisphere =0; hemisphere <= HEMI_QTY; hemisphere++) {
    for (int panel = 1; panel <=PANE_QTY; panel++) {
      for (int cell = 0; cell <CELL_QTY; cell++) {
        reading = I2C_request(hemisphere, panel, cell);
        cell_readings[hemisphere][panel-1][cell] = reading;
      }
    }
  }
  return true;
}
void MainControllerSetup() {
  
  consolePrintf("Intializing I2C at %dHz", globalConfig.i2cFrequency * 1000);
  //I2C initilization
  // Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, globalConfig.i2cFrequency * 1000);
  // Wire1.begin(I2C2_SDA_PIN, I2C2_SCL_PIN, globalConfig.i2cFrequency * 1000);
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN,I2C_FREQ);
  Wire1.begin(I2C2_SDA_PIN, I2C2_SCL_PIN, I2C_FREQ);


  espNowSetup();

  //Serial communication initialization
  Serial.begin(115200);
  delay(60);
  debug_println("Serial communication started...");

}


void MainControllerLoop() {
  // debug_println("Loop");
  static String lastMode = " ";
  static bool override = false; // was override on last run?

  uint8_t cell = globalConfig.pressThreshold;
  uint8_t panel = globalConfig.releaseThreshold;
  uint8_t hemisphere = globalConfig.maxThreshold;
  uint8_t address = cellToAddress(hemisphere, panel, cell);


  if (lastMode == " ") {
    // we've just booted up
    lastMode = "Standby";
    if (hemisphere == 2) {
    I2C_send_mode(&Wire, (uint8_t) address, lastMode);
    I2C_send_mode(&Wire1, (uint8_t) address, lastMode);
    } else if (hemisphere == 1) {
      I2C_send_mode(&Wire1, (uint8_t) address, lastMode);
    } else {
      I2C_send_mode(&Wire, (uint8_t) address, lastMode);
    }
    consolePrintf("Bootup Complete, Setting Mode To: %s \n",lastMode);
  }

  // if (lastMode == "Simon") {
  //   playSimon();
  // }
  if (lastMode == "Music") { // This is actually our "Hybrid Mode"
    if (poll_cells()){ sendAllMidi();}
  }

  if (lastMode == "Light") { // with music too
    if (poll_cells()){ sendAllMidi();}
  }

  if (lastMode == "Flash") {
    if (poll_cells()){ flash();}
  }

  if (lastMode == "Standby") {
    orbit();
    if (poll_cells()){ sendAllMidi();}
  }


  if (override != globalConfig.modeOverrideEnabled) {
    override = globalConfig.modeOverrideEnabled;
    consolePrintf("MODE: Setting Overide to: %d\n", override);
  }
  // Handle Mode Control Between User and Override
  if (globalConfig.modeOverrideEnabled) {
    // Control mode in override
    if (lastMode != globalConfig.modeOverride) {
      lastMode = globalConfig.modeOverride;
      globalConfig.modeUser = globalConfig.modeOverride;
      if (globalConfig.modeUser == "Music") {  //Actually Hybrid Mode
        hybrid_mode();
      } else {

      if (hemisphere == 2) {
        I2C_send_mode(&Wire, (uint8_t) address, globalConfig.modeOverride);
        I2C_send_mode(&Wire1, (uint8_t) address, globalConfig.modeOverride);
      } else if (hemisphere == 1) {
        I2C_send_mode(&Wire1, (uint8_t) address, globalConfig.modeOverride);
      } else {  
        I2C_send_mode(&Wire, (uint8_t) address, globalConfig.modeOverride);
      }
      consolePrintf("MODE: Setting Override Mode: %s\n", globalConfig.modeOverride);
    }
  }

  } else { // Control Mode from User input
      // // Send New Mode if it changed
      // if (lastMode != globalConfig.modeUser) {
      //   lastMode = globalConfig.modeUser;
      //   if (hemisphere == 2) {
      //     I2C_send_mode(&Wire, (uint8_t) address, globalConfig.modeUser);
      //     I2C_send_mode(&Wire1, (uint8_t) address, globalConfig.modeUser);
      //   } else if (hemisphere == 1) {
      //     I2C_send_mode(&Wire1, (uint8_t) address, globalConfig.modeUser);
      //   } else {
      //     I2C_send_mode(&Wire, (uint8_t) address, globalConfig.modeUser);
      //   }
      //   consolePrintf("MODE: Setting User Mode: %s\n", globalConfig.modeUser);
      // }

  }



    // int len = millis()-lastsweep;
    // consolePrintf("Full sweep run in : %ums \n",len);
    delay(1); // idk maybe this will help

}

  // NOTE: Yes using a String for the mode is stupid, this was the quick way of adapting the AI code to work so we could test
  // send SET MODE command if its changed since last run
  // if (lastMode != globalConfig.modeUser) { // check current mode matches last mode
  //   I2C_send_mode(0x00U, globalConfig.modeUser); // send new mode
  // }

  // I2C_send_mode((uint8_t)0x00U, "Debug");

// ST AN4221 I2C Bootloader Protocol Implementation
// According to AN4221, the protocol requires:
// - Write Memory command (0x31) followed by its complement (0xCE)
// - 4-byte address (MSB first) + checksum (XOR of address bytes)
// - Data length byte (N-1) + data bytes + checksum (XOR of length + data)
// - Each packet must be sent separately with ACK verification

#define BOOTLOADER_ENTER_CMD 0x0FU  // Enter bootloader mode command (Note, this is custom as it runs when our regular app is running)
#define BOOTLOADER_NO_STRETCH_WRITE_MEMORY_CMD 0x32U  // Write Memory command
#define BOOTLOADER_NO_STRETCH_WRITE_MEMORY_COMPLEMENT 0xCD // Complement of Write Memory command
#define BOOTLOADER_CHUNK_SIZE 64  // Maximum data bytes per packet (N-1 format, so 128 bytes = 0x7F)
#define BOOTLOADER_START_ADDRESS 0x08000000U  // Typical STM32 flash start address
#define BOOTLOADER_ADDRESS 0x56U  // Default bootloader address

#define BOOTLOADER_ACK  0x79
#define BOOTLOADER_NACK 0x1F
#define BOOTLOADER_BUSY 0x76



// Calculate checksum: XOR of all bytes
uint8_t calculateChecksum(uint8_t* data, uint8_t len) {
  uint8_t checksum = 0;
  for (uint8_t i = 0; i < len; i++) {
    checksum ^= data[i];
  }
  return checksum;
}


uint8_t waitAck(TwoWire* WirePtr) {
  static uint32_t delayTime = 1;
  while (1) {
    // Check for ACK Byte
    (*WirePtr).requestFrom(BOOTLOADER_ADDRESS, 1);
    uint8_t error = (*WirePtr).read();
    if (error == BOOTLOADER_ACK) {
      delayTime = 1;
      // consolePrintln("BOOT: RECV ACK");
      return 0;
    } else if (error == BOOTLOADER_NACK) {
      consolePrintln("BOOT: RECV NACK");
      return 2;
      delayTime++;
    } else if (error == BOOTLOADER_BUSY) {
      // consolePrintln("BOOT: RECV BUSY");
      delayTime++;
    } else {
      consolePrintln("BOOT: Invalid Response");
      return 1;
    }
    delay(delayTime);
  }

}

union writeAddress {
  uint32_t address32;
  uint8_t address8[4];
};

uint8_t cellToAddress(uint8_t hemisphere, uint8_t panel, uint8_t cell) {
  uint8_t address = (panel * 8) + cell; // lowest octal address
  // address += hemisphere * 128; // store hemisphere value as MSB of address byte to avoid having to pass wire object to other functions
  // address += (panel * 5);
  // address += (cell * 8);
  return address;
}

TwoWire* getBus (uint8_t hemisphere) {
  switch (hemisphere) {
    case 0:
      return &Wire;
      break;
    case 1:
      return &Wire1;
      break;
    default:
      return NULL;
  }
}

uint8_t erasePage(TwoWire* WirePtr, uint8_t page) {
    uint8_t error = 0;
    uint8_t chk = 0;

    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(0x45);
    (*WirePtr).write(0xBA);
    error = (*WirePtr).endTransmission(true);
    if (error) {
      consolePrintln("BOOT: I2C: ERROR");
    }
    
    if (waitAck(WirePtr)) {
      return 1;// busy poll until ACK
    } 

    // Tell bootloader we're erasing 1 page
    chk = 0;
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(0x00);  
    (*WirePtr).write(0x00); 
    (*WirePtr).write(0x00); // XOR Checksum of command
    error = (*WirePtr).endTransmission(true);

    if (error) {
      consolePrintln("BOOT: I2C: ERROR");
    }

    if (waitAck(WirePtr)) {
      return 1;// busy poll until ACK
    } 

    chk = 0; // init check sum var
    consolePrintf("BOOT: Erasing Page %d\n", page);
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(0x00);
    (*WirePtr).write(page);
    chk ^= 0x00;
    chk ^= page;
    (*WirePtr).write(chk);
    error = (*WirePtr).endTransmission(true);

    if (error) {
      consolePrintln("BOOT: I2C: ERROR");
    }
    
    if (waitAck(WirePtr)) {
      return 1;// busy poll until ACK
    } 
    return 0;
}

void updateCell(uint8_t hemisphere, uint8_t panel, uint8_t cell, uint8_t* firmware, size_t size) { // update single cell
  if (hemisphere == 2) {
    updateCell (0,panel,cell,firmware,size);
    updateCell (1,panel,cell,firmware,size);
    return;
  }
  uint8_t address = cellToAddress(hemisphere, panel, cell);
  TwoWire* WirePtr = getBus(hemisphere);

  // if (hemisphere) {
  //   WirePtr = &Wire1;
  // } else {
  //   WirePtr = &Wire;
  // }

  consolePrintf("Updating Cell 0x%01x \n", address);
  // consolePrintf("Starting I2C bootloader update for address 0x%01X\n", address);
  
  // Get our 32-bit address in a union so its easier to split up
  union writeAddress startAddress;
  startAddress.address32 = BOOTLOADER_START_ADDRESS;
  uint8_t error;
  // Enter bootloader mode
  for (int i=0; i<3; i++) {
    (*WirePtr).beginTransmission(address);
    (*WirePtr).write(BOOTLOADER_ENTER_CMD);
    error = (*WirePtr).endTransmission(true);
    if (!error) {
      consolePrintf ("Success on try # %d \n", i);
      break;
    }
    consolePrintf ("Fail on try # %d \n", i);

    // if (i==2){
    //   consolePrintln("Skipping Cell");
    //   return;
    // }    
    delay(200);
  }
  // // Verify Bootloader is launched
  consolePrintln("Verifying Boot Mode...");

  // Wire.beginTransmission()

    // Send Erase command for all pages except configuration page

  // Start command
  consolePrintln("Erasing Sub-controller");
  for (uint8_t i = 0; i < 14; i++) {
    error = erasePage(WirePtr, i);

    if (error) { // TODO: possible infinite loop should break after certain number of fails
      consolePrint("BOOT: Erase Fail, Retry\n");
      i--;
      continue;
    }
  }
  // At this point the chip is erased

  consolePrintln("BOOT: Erased Sub-controller");
  consolePrintln("BOOT: Flashing New Firmware");

  // Write new firmware
  
  // Write command only supports up to 256 bytes at a time so we need to chunk the writes
  uint32_t numChunks = size / BOOTLOADER_CHUNK_SIZE; // get number of full chunks
  uint32_t sizeRemainder = size % BOOTLOADER_CHUNK_SIZE; // get amount of bytes in final chunk
  uint32_t offset = 0; // tracker for offset from base write address

  for (uint32_t i = 0; i < numChunks; i++) { // write full chunks
    // Start write command
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(0x32);
    (*WirePtr).write(0xCD);
    (*WirePtr).endTransmission(true);
    if (waitAck(WirePtr)) {
      i--;
      continue;
    } 
    // consolePrintln("BOOT: Write CMD Accepted");

    // Send start address for this chunk
 
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    // Wire.write(startAddress.address8, 4);
    (*WirePtr).write(startAddress.address8[3]);
    (*WirePtr).write(startAddress.address8[2]);
    (*WirePtr).write(startAddress.address8[1]);
    (*WirePtr).write(startAddress.address8[0]);
    (*WirePtr).write(calculateChecksum(startAddress.address8, 4));
    (*WirePtr).endTransmission(true);
    if (waitAck(WirePtr)) {
      i--;
      continue;
    } 
    // consolePrintf("BOOT: Writing %d Bytes at 0x%08x\n", BOOTLOADER_CHUNK_SIZE, startAddress.address32);

    // Write Data for this chunk
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(BOOTLOADER_CHUNK_SIZE - 1); // queue number of bytes to be sent
    uint8_t chk = 0;
    for (uint8_t ii = 0; ii < BOOTLOADER_CHUNK_SIZE; ii++) {
      // Queue BOOTLOADER_CHUNK_SIZE bytes
      uint8_t dat = firmware[ii + offset]; // get current data byte
      chk ^= dat; // update checksum
      (*WirePtr).write(dat); // queue data byte
    }
    chk ^= BOOTLOADER_CHUNK_SIZE - 1;
    (*WirePtr).write(chk); // queue checksum byte
    (*WirePtr).endTransmission(true);

    if (waitAck(WirePtr)) {
      i--;
      continue;
    } 
    // consolePrintf("BOOT: Wrote %d Bytes at %d /n", BOOTLOADER_CHUNK_SIZE, startAddress.address32);
    offset += BOOTLOADER_CHUNK_SIZE; // increment offset for next go round
    startAddress.address32 += BOOTLOADER_CHUNK_SIZE; // increment start address
    delay(1);
  }

  
  
  if (sizeRemainder != 0) { // only do this if there is actual data to write
    while(1){
      // Write final partial chunk
      // Start write command
      (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
      (*WirePtr).write(0x32);
      (*WirePtr).write(0xCD);
      (*WirePtr).endTransmission(true);
      if (waitAck(WirePtr)) {
        continue;
      } 
      consolePrintln("BOOT: Write CMD Accepted");

      // Send start address for this chunk
      (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
      // Wire.write(startAddress.address8, 4);
      (*WirePtr).write(startAddress.address8[3]); // done this way cause using union directly makes it come out backwards
      (*WirePtr).write(startAddress.address8[2]);
      (*WirePtr).write(startAddress.address8[1]);
      (*WirePtr).write(startAddress.address8[0]);
      (*WirePtr).write(calculateChecksum(startAddress.address8, 4));
      (*WirePtr).endTransmission(true);
      if (waitAck(WirePtr)) {
        continue;
      } 
      consolePrintf("BOOT: Writing %d Bytes at 0x%08x\n", sizeRemainder, startAddress.address32);

      // Write Data for this chunk
      (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
      (*WirePtr).write(sizeRemainder - 1); // queue number of bytes to be sent
      uint8_t chk = 0;
      for (uint8_t i = 0; i < sizeRemainder; i++) {
        // Queue BOOTLOADER_CHUNK_SIZE bytes
        uint8_t dat = firmware[i + offset]; // get current data byte
        chk ^= dat; // update checksum
        (*WirePtr).write(dat); // queue data byte
      }
      chk ^= sizeRemainder - 1;
      (*WirePtr).write(chk); // queue checksum byte
      (*WirePtr).endTransmission(true);

      if (waitAck(WirePtr)) {
        continue;
      } 
      break;
    }
  }

  consolePrintln("BOOT: Rebooting");
  // reboot into new firmware
  while(1) {
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(0x21);
    (*WirePtr).write(0xDE);
    (*WirePtr).endTransmission(true);
    if (waitAck(WirePtr)) {
      continue;
    } 
    // Wire.write(BOOTLOADER_START_ADDRESS, 4);
    startAddress.address32 = BOOTLOADER_START_ADDRESS;
    (*WirePtr).beginTransmission((uint8_t)BOOTLOADER_ADDRESS);
    (*WirePtr).write(startAddress.address8[3]);
    (*WirePtr).write(startAddress.address8[2]);
    (*WirePtr).write(startAddress.address8[1]);
    (*WirePtr).write(startAddress.address8[0]);
    (*WirePtr).write(calculateChecksum(startAddress.address8, 4));
    (*WirePtr).endTransmission(true);
    if (waitAck(WirePtr)) {
      continue;
    } 
    break;
  }
}

// void updatePanel(uint8_t hemisphere, uint8_t panel, uint8_t* firmware, size_t size) { // update a panel
//   consolePrintf("Updating Hemisphere %d Panel %d\n", hemisphere, panel);
//   for (uint8_t i = 0; i < 8; i++) {
//     updateCell(hemisphere, panel, i, firmware, size);
//     delay(200);
//   }
// }

// void updateHemisphere(uint8_t hemisphere, uint8_t* firmware, size_t size) { // update one hemisphere
//   consolePrintf("Updating Hemisphere %d\n", hemisphere);
//   for (uint8_t i = 1; i <=5; i++) {
//     updatePanel(0, i, firmware, size);
//   }
// }

// void updateMoon(uint8_t* firmware, size_t size) { // update entire moon
//   consolePrintln("Updating Entire Moon");
//   updateHemisphere(0, firmware, size);
//   updateHemisphere(1, firmware, size);

// }

#define NUM_SIMON_CELLS 10
#define NUM_SIMON_GUESSES 10
// Initiate and play a game of simon. 
// Exit when user wins or looses or no input in xx seconds.
// void playSimon() {
//   consolePrintln("Playing Simon...");

//   // A game board with a specific set of addresses.
// static uint8_t gameBoardCells[NUM_SIMON_CELLS][3] = { { 0, 4, 4},
//                                                       { 0, 5, 1},
//                                                       { 0, 4, 3},
//                                                       { 0, 4, 7},
//                                                       { 0, 5, 2},
//                                                       { 1, 3, 3},
//                                                       { 1, 3, 2},
//                                                       { 1, 3, 4},
//                                                       { 1, 3, 0},
//                                                       { 1, 3, 1}}; 

//   // The colours to display in each cell by address.
//   static uint32_t gameBoardColours[NUM_SIMON_CELLS];

//   // How many cells to displayed in the current sequence.
//   static uint8_t numberInSequence = 1;
//   static uint8_t currentUserSelection = 0;

//   // Get the pressure readingfrom a call.
//   uint8_t pressure;
//   uint32_t colourRed = strip.ColorHSV(0, 255, 255);

//   // TODO: Find out a good hue value for a bright green.
//   uint32_t colourGreen = strip.ColorHSV(8000, 255, 255);

//   // Initialize the game board with a specific set of addresses. 
//   // gameBoardCells[0] = {0, 4, 4};
//   // gameBoardAddresses[1] = {0, 5, 1};
//   // gameBoardAddresses[2] = cellToAddress(0, 4, 3);
//   // gameBoardAddresses[3] = cellToAddress(0, 4, 7);
//   // gameBoardAddresses[4] = cellToAddress(0, 5, 2);
//   // gameBoardAddresses[5] = cellToAddress(1, 3, 3);
//   // gameBoardAddresses[6] = cellToAddress(1, 3, 2);
//   // gameBoardAddresses[7] = cellToAddress(1, 3, 4);
//   // gameBoardAddresses[8] = cellToAddress(1, 3, 0);
//   // gameBoardAddresses[9] = cellToAddress(1, 3, 1);

//   // Initialize ten different colours.
//   uint16_t step = (65535-1)/(NUM_SIMON_CELLS+1);
//   uint16_t hue = step;
//   for (int i = 0; i < NUM_SIMON_CELLS; i++) {
//     gameBoardColours[i] = strip.ColorHSV(hue, 255, 255);
//     hue += step;
//   }
//   // Now randomize the order of the game board cells.
//   std::random_shuffle( std::begin( gameBoardCells ), std::end( gameBoardCells ));

//   // Main game loop.
//   while (true) {
//     // Show the current sequence.
//     for (int i = 0; i < numberInSequence; i++) {
//       // Show gameBoardColours[i] at cell gameBoardAddresses[i];
//       I2C_send_col(cellToAddress(gameBoardCells[i]), gameBoardColours[i]); 
//         consolePrintf("Simon: Flashing H%dP%dC%d \n",gameBoardCells[i][0],gameBoardCells[i][1],gameBoardCells[i][2]);
//       // Pause for a bit after each shown. 
//       delay(500);
//     }

//     // Clear the current sequence.
//     for (int i = 0; i < numberInSequence; i++) {
//       // Turn off cell colours for the currect sequence.
//       I2C_send_col(gameBoardCells[i], 0);
//     }
//     // Poll for user pressing cells. 
//     static uint8_t currentUserSelection = 0;
//     for (int i = 0; i < numberInSequence; i++) {
//       for (int j = 0; j < NUM_SIMON_CELLS; j++) {
//         // Has cell at gameBoardAddresses[j] been pressed?
//         pressure = I2C_request(gameBoardCells[j]);
//         if (pressure) {
//           // See if the cell pressed is the one expected. 
//           if (j == currentUserSelection) {
//             // Light up the cell pressed with the appropriate colour.
//             I2C_send_col(gameBoardCells[j], gameBoardColours[j]);
              
//           } else {
//             // User failed so blink all cells RED then clear.
//             for (int i = 0; i < NUM_SIMON_CELLS; i++) {
//               // Turn the cells RED.
//               I2C_send_col( gameBoardCells[i], colourRed);
//             }
//             // TODO: Do we want blinking?
//             delay(2000);
//             // Clear all the cells on the game board.
//             for (int i = 0; i < NUM_SIMON_CELLS; i++) {
//               // Turn the cells RED.
//               I2C_send_col(gameBoardCells[i], 0);
//             }
//             return;
//           }
//         }
//       }
//       // Get ready for the next user press. 
//       currentUserSelection++;
//     }

//     // If we get here the user has gotten the correct sequence so far. 
//     // Increase sequence length.
//     numberInSequence++;
//     if (numberInSequence > NUM_SIMON_GUESSES) {
//       // Successfully completed the sequence.
//       for (int i = 0; i < NUM_SIMON_CELLS; i++) {
//         // Turn the cells GREEN.
//         I2C_send_col(gameBoardCells[i], colourGreen);
//       }
//       // TODO: Do we want blinking?
//       delay(5000);
//       // Successfully completed the sequence.
//       for (int i = 0; i < NUM_SIMON_CELLS; i++) {
//         // lear the cells.
//         I2C_send_col(gameBoardCells[i], 0);
//       }
//       return;
//     }
//   }
// }

void updateSubController(uint8_t address, uint8_t* firmware, size_t size) { 
  consolePrintf("Starting Sub-controller Update Routine\n");
  consolePrintf("Firmware size: %u bytes\n", size);

  // for (uint8_t i = 0; i < 1; i++) {
  //   updateCell(0, 1, i, firmware, size);
  // delay(200);
  // }
  // updateHemisphere(0, firmware, size);
  uint8_t cell = globalConfig.pressThreshold;
  uint8_t panel = globalConfig.releaseThreshold;
  uint8_t hemisphere = globalConfig.maxThreshold;
  updateCell(hemisphere, panel, cell, firmware, size);
  // updateCell(1, 0, 0, firmware, size);
  // updateMoon(firmware, size);

}