#include <ESP32Servo.h>
#include <Adafruit_NeoPixel.h>
#include <esp_now.h>
#include <WiFi.h>
#include "esp_now_midi.h"
#include <Adafruit_TinyUSB.h>
#include <MIDI.h>

//**********PINS*********
#define TILT_SERVO_PIN 5
#define ROTATE_SERVO_PIN 15
#define LED_PIN    4
#define SWITCH_PIN    41
#define LED_COUNT 70


//***********SERVO STUFF**********
#define TILT_PERIOD 10000
#define TILT_SERVO_HOME 600
#define TILT_SERVO_TRAVEL 75
#define TILT_SERVO_MIN TILT_SERVO_HOME - TILT_SERVO_TRAVEL
#define TILT_SERVO_MAX TILT_SERVO_HOME + TILT_SERVO_TRAVEL

#define TILT_SPEED 0.2

#define ROTATE_PERIOD 30000
#define ROTATE_SERVO_FLAP_PERIOD 3000
#define ROTATE_SERVO_HOME 1500
#define ROTATE_SERVO_TRAVEL 1000
#define ROTATE_SERVO_FLAP_TRAVEL 70

#define ROTATE_SERVO_MIN ROTATE_SERVO_HOME - ROTATE_SERVO_TRAVEL
#define ROTATE_SERVO_MAX ROTATE_SERVO_HOME + ROTATE_SERVO_TRAVEL

#define PAUSE_FRONT_ROTATE_POSITION 680
#define PAUSE_FRONT_TILT_POSITION TILT_SERVO_HOME
#define PAUSE_BACK_ROTATE_POSITION 2050
#define PAUSE_BACK_TILT_POSITION TILT_SERVO_HOME

#define ROTATE_SERVO_FRONT_FLAP_MIN PAUSE_FRONT_ROTATE_POSITION - ROTATE_SERVO_FLAP_TRAVEL
#define ROTATE_SERVO_FRONT_FLAP_MAX PAUSE_FRONT_ROTATE_POSITION + ROTATE_SERVO_FLAP_TRAVEL

#define ROTATE_SERVO_BACK_FLAP_MIN PAUSE_BACK_ROTATE_POSITION - ROTATE_SERVO_FLAP_TRAVEL
#define ROTATE_SERVO_BACK_FLAP_MAX PAUSE_BACK_ROTATE_POSITION + ROTATE_SERVO_FLAP_TRAVEL

#define ROTATE_SPEED 0.2

#define MODE_QTY 6
#define MODE_MOTION1 0
#define MODE_PAUSE_FRONT 1
#define MODE_FLAP_FRONT 2
#define MODE_MOTION2 3
#define MODE_PAUSE_BACK 4
#define MODE_FLAP_BACK 5


#define MODE_DURATION 60000


Servo tilt_servo;  // create servo object to control a servo
Servo rotate_servo;  // create servo object to control a servo
// 16 servo objects can be created on the ESP32
float tilt_position;
float rotate_position;
bool shutdown;
bool shutdown_complete;
long motion_start_time;
long last_update_time;
long last_mode_change;
uint8_t mode;


void setup_servos(){
	// Allow allocation of all timers
	ESP32PWM::allocateTimer(0);
	ESP32PWM::allocateTimer(1);
	ESP32PWM::allocateTimer(2);
	ESP32PWM::allocateTimer(3);
	tilt_servo.setPeriodHertz(250);    // standard 50 hz servo
	tilt_servo.attach(TILT_SERVO_PIN, 500, 2500); // attaches the servo on pin 18 to the servo object
	rotate_servo.setPeriodHertz(250);    // standard 50 hz servo
	rotate_servo.attach(ROTATE_SERVO_PIN, 500, 2500); // attaches the servo on pin 18 to the servo object
 	delay(5000);
	long start = millis();
	while(millis()<(start+10000)) {
		tilt_servo.writeMicroseconds(TILT_SERVO_HOME);
		rotate_servo.writeMicroseconds(ROTATE_SERVO_HOME);
	}
	tilt_position = TILT_SERVO_HOME;
	rotate_position = ROTATE_SERVO_HOME;
	motion_start_time = last_mode_change = millis();
	mode = 0;
	
}

void sweep_servo(Servo* servo, int min, int max, int period) {
	static long start_time = millis();
	int steps = (max-min)*2;
	int msperstep = period/steps;
	int pos;
	long time = (millis()-start_time)%period;
	int step = map(time,0,period-1,0,steps-1);
	if (step < steps/2) {
		pos = min + step;
	} else {
		pos = max - (step - steps/2);
	}
	pos = constrain (pos, min, max);
	(*servo).writeMicroseconds(pos);    // tell servo to go to position in variable 'pos'
}

float sweep_servo_sine(Servo* servo, float cur_position, float speed, int min, int max, int period) {
	int amplitude = (max-min)/2;
	int offset = (min+max)/2;
	long time = (millis()-motion_start_time)%period;
	float rad = time/float(period) *2*PI;
	float pos;
	pos = (amplitude * sin(rad) + offset);
	Serial.println(int(pos));
	pos = constrain (pos, min, max);
	pos = servo_goto(servo, cur_position, pos, speed);
	// (*servo).writeMicroseconds(int(pos));    // tell servo to go to position in variable 'pos'
	return pos;
}

float servo_goto (Servo* servo, float cur_position, float target_position, float speed) {
	Serial.print("servo_goto : ");
	long elapsed_time = millis()-last_update_time;
	int direction;
	if (cur_position > target_position) {direction = -1;}
	else {direction = 1;}
	float new_position = constrain_reverse(cur_position + direction*elapsed_time*speed, cur_position, target_position);
	Serial.println(int(new_position));
	(*servo).writeMicroseconds(int(new_position));
	return new_position;

}
void servo_stuff() {
	switch (mode) {
		case MODE_MOTION1:
		case MODE_MOTION2:
			tilt_position = sweep_servo_sine(&tilt_servo, tilt_position, TILT_SPEED, TILT_SERVO_MIN, TILT_SERVO_MAX, TILT_PERIOD);
			rotate_position =  sweep_servo_sine(&rotate_servo, rotate_position, ROTATE_SPEED, ROTATE_SERVO_MIN, ROTATE_SERVO_MAX, ROTATE_PERIOD);
		break;
		case MODE_PAUSE_FRONT:
			tilt_position = servo_goto(&tilt_servo, tilt_position, PAUSE_FRONT_TILT_POSITION, TILT_SPEED);
			rotate_position = servo_goto(&rotate_servo, rotate_position,PAUSE_FRONT_ROTATE_POSITION, ROTATE_SPEED);
		break;
		case MODE_PAUSE_BACK:
			tilt_position = servo_goto(&tilt_servo, tilt_position, PAUSE_BACK_TILT_POSITION, TILT_SPEED);
			rotate_position = servo_goto(&rotate_servo, rotate_position,PAUSE_BACK_ROTATE_POSITION, ROTATE_SPEED);
		break;
		case MODE_FLAP_FRONT:
			rotate_position =  sweep_servo_sine(&rotate_servo, rotate_position, ROTATE_SPEED, ROTATE_SERVO_FRONT_FLAP_MIN, ROTATE_SERVO_FRONT_FLAP_MAX, ROTATE_SERVO_FLAP_PERIOD);
			break;
		case MODE_FLAP_BACK:
			rotate_position =  sweep_servo_sine(&rotate_servo, rotate_position, ROTATE_SPEED, ROTATE_SERVO_BACK_FLAP_MIN, ROTATE_SERVO_BACK_FLAP_MAX, ROTATE_SERVO_FLAP_PERIOD);
	}
	last_update_time = millis();

}

float constrain_reverse(float amt, float limit1, float limit2) {
	if (limit1 > limit2) {
		return constrain(amt, limit2, limit1);
	} else {
		return constrain(amt, limit1, limit2);
	}
}
void servo_shutdown () {
	if (!shutdown_complete) {
		tilt_position = servo_goto(&tilt_servo, tilt_position,TILT_SERVO_HOME, TILT_SPEED);
		rotate_position = servo_goto(&rotate_servo, rotate_position,ROTATE_SERVO_HOME, ROTATE_SPEED);
		last_update_time = millis();
		if( (tilt_position == TILT_SERVO_HOME) && (rotate_position == ROTATE_SERVO_HOME)) {
			shutdown_complete = true;
		}
		
	}
}

//*********LED STUFF*********

#define HUES 2000
#define TIMESCALE 1
#define DELAY 5
#define LEFT_INSIDE_START 7
#define LEFT_INSIDE_LEN 13
#define LEFT_OUTSIDE_START 22
#define LEFT_OUTSIDE_LEN 14
#define RIGHT_INSIDE_START 56
#define RIGHT_INSIDE_LEN 13
#define RIGHT_OUTSIDE_START 40
#define RIGHT_OUTSIDE_LEN 14

// Declare our NeoPixel strip object:
Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_RGB + NEO_KHZ400);
// Argument 1 = Number of pixels in NeoPixel strip
// Argument 2 = Arduino pin number (most are valid)
// Argument 3 = Pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
//   NEO_RGBW    Pixels are wired for RGBW bitstream (NeoPixel RGBW products)

void setup_LEDs() {
  strip.begin();           // INITIALIZE NeoPixel strip object (REQUIRED)
  strip.show();            // Turn OFF all pixels ASAP
  strip.setBrightness(255); // Set BRIGHTNESS to about 1/5 (max = 255)
}

void LED_stuff(){

  // int start = LEFT_INSIDE_START;
  // int len = LEFT_INSIDE_LEN;

  // strip.clear();         //   Set all pixels in RAM to 0 (off)
  rotate_rainbow(LEFT_INSIDE_START, LEFT_INSIDE_LEN,false);
  rotate_rainbow(LEFT_OUTSIDE_START, LEFT_OUTSIDE_LEN,true);
  rotate_rainbow(RIGHT_INSIDE_START, RIGHT_INSIDE_LEN,true);
  rotate_rainbow(RIGHT_OUTSIDE_START, RIGHT_OUTSIDE_LEN,true);
  // rotate_stack(RIGHT_OUTSIDE_START, RIGHT_OUTSIDE_LEN,0xFFFFFF,false);
  // rainbow_fade(RIGHT_INSIDE_START, RIGHT_INSIDE_LEN);
 	// colour_fill(RIGHT_OUTSIDE_START, RIGHT_OUTSIDE_LEN,0xFF0000);


  strip.show();
}

#define STACK_REPEAT 5000 //in ms

void colour_fill(uint8_t start, uint8_t len,uint32_t colour) {
	for (int i=start; i<(start+len); i++) {
		strip.setPixelColor(i,colour);
	}
}



void rotate_stack(uint8_t start, uint8_t len,uint32_t colour, bool reverse) {
  uint16_t steps = (len * (len+1)) /2 + 1; // number of steps in full pattern
  uint16_t curstep = map (millis() % STACK_REPEAT, 0, STACK_REPEAT, 0, steps);
  bool on = false;  
  uint8_t position;
  uint64_t pattern = stack_pattern(steps, curstep);  
  for (int i=start; i<(start+len); i++){
    if (reverse) {position = len - (i-start); }
    else         {position =     + (i-start); }
    on = ((pattern >> position) & 1 );
    strip.setPixelColor(i,on*colour);
  }
}

uint64_t stack_pattern(uint16_t n,uint16_t i){
  if (i == 0) {return 0; }
  if (n >= 2) { return i; }
  if (i < n) { return 2^(i-1);}
  return ( 2^(n-1) + stack_pattern(n-1,i));
}

void rainbow_fade(uint8_t start, uint8_t len){
  uint16_t hue;
  uint16_t shift = (millis()/(TIMESCALE))%HUES;
	hue = map(shift,0,HUES-1,0,65535);
  for (int i=start; i<(start+len); i++){
    strip.setPixelColor(i,strip.ColorHSV(hue,255,255));
  }
}

void rotate_rainbow(uint8_t start, uint8_t len,bool reverse){
  uint16_t hue;
  uint16_t shift = (millis()/(TIMESCALE))%HUES;
  for (int i=start; i<(start+len); i++){
    if (reverse) {
      hue = (((len-(i-start))*HUES)/len+shift)%HUES*(65535/HUES);
    } else {
      hue = ((((i-start))*HUES)/len+shift)%HUES*(65535/HUES);
    }
    strip.setPixelColor(i,strip.ColorHSV(hue,255,255));
  }
}

void LED_test(){

	strip.clear();
	strip.setPixelColor(12,0xFF,0XFF,0xFF);
	strip.show();
}

void LED_shutdown () {
	if (!shutdown_complete) 
		strip.clear();
		strip.show();
}

//********MIDI STUFF*********

// USB MIDI object
Adafruit_USBD_MIDI usb_midi;

esp_now_midi ESP_NOW_MIDI;

// Attach usb_midi as the transport.
MIDI_CREATE_INSTANCE(Adafruit_USBD_MIDI, usb_midi, MIDI);

uint8_t macAddressMoth[]  =  {0x12, 0x34, 0x56, 0x78, 0x9A, 0x00};
uint8_t macAddressMoon[]  =  {0x12, 0x34, 0x56, 0x78, 0x9A, 0x01};


// there has been a change in the callback signature with esp32 board version 3.3.0, hence this is here for backwards compatibility
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 3, 0)
void customOnDataSent(const wifi_tx_info_t* info, esp_now_send_status_t status) {
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Success" : "Failure");
}
#else
void customOnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Success" : "Failure");
}
#endif

void onNoteOn(byte channel, byte note, byte velocity) {
	Serial.printf("Note ON: channel:%d, note:%d, velocity:%d \n", channel, note, velocity);
  MIDI.sendNoteOn(note, velocity, channel);
}

void onNoteOff(byte channel, byte note, byte velocity) {
	Serial.printf("Note OFF: channel:%d, note:%d, velocity:%d \n", channel, note, velocity);
  MIDI.sendNoteOff(note, velocity, channel);
}

void onPolyAfterTouch(byte channel, byte note, byte value) {
	Serial.printf("Poly After Touch: channel:%d, note:%d, value:%d \n", channel, note, value);
  MIDI.sendAfterTouch(note, value, channel);
}

void handleNoteOn(byte channel, byte note, byte velocity){}
void handleNoteOff(byte channel, byte note, byte velocity){}

void MIDIsetup() {
  // Manual begin() is required on core without built-in support e.g. mbed rp2040
  if (!TinyUSBDevice.isInitialized()) {
    TinyUSBDevice.begin(0);
  }

  Serial.begin(115200);
  usb_midi.setStringDescriptor("TinyUSB MIDI");

  // Initialize MIDI, and listen to all MIDI channels
  MIDI.begin(MIDI_CHANNEL_OMNI);

  // If already enumerated, re-enumerate
  if (TinyUSBDevice.mounted()) {
    TinyUSBDevice.detach();
    delay(10);
    TinyUSBDevice.attach();
  }

  MIDI.setHandleNoteOn(handleNoteOn);
  MIDI.setHandleNoteOff(handleNoteOff);
}
void esp_now_setup() {
  WiFi.mode(WIFI_STA);
  esp_wifi_set_mac(WIFI_IF_STA, macAddressMoth);

  ESP_NOW_MIDI.setup(macAddressMoon, customOnDataSent);

  ESP_NOW_MIDI.setHandleNoteOn(onNoteOn);
  ESP_NOW_MIDI.setHandleNoteOff(onNoteOff);
  ESP_NOW_MIDI.setHandleAfterTouchPoly(onPolyAfterTouch);

  // register as a client by sending any message
  ESP_NOW_MIDI.sendControlChange(127, 127, 16);
}

//********GENERAL STUFF*******

void	change_mode() {
	if (millis() > (last_mode_change + MODE_DURATION)) {
		mode = (mode+1)%MODE_QTY;
		last_mode_change = motion_start_time = last_update_time = millis();
		Serial.printf("New Mode : %d\n",mode);
	}

}

void check_switch() {
	if (digitalRead(SWITCH_PIN)) { //Set to off
		if (!shutdown) {
			shutdown = true;
			shutdown_complete = false;
			last_update_time = millis();

		}
	} else {  //set to on
		if (shutdown == true) {
			motion_start_time = last_mode_change = millis();
			mode = 0;
			shutdown = false;
		}
	}
}

void setup() {
	Serial.begin(115200);
	Serial.println("Serial...");
	esp_now_setup();
	MIDIsetup();
	setup_LEDs();
	setup_servos();
	pinMode(SWITCH_PIN,INPUT_PULLUP);
	
}

void loop() {
	// Serial.println("loop...");
	check_switch();
	change_mode();
	if (shutdown) {
		servo_shutdown();
		LED_shutdown();
	} else {
		servo_stuff();
		LED_stuff();
	}
	// LED_test();
	delay(10);
}

