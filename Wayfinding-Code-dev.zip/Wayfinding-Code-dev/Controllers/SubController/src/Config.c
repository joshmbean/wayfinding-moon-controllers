#ifdef __cplusplus
extern "C"
{
#endif

// Functions for handling storage and retreival of configuration data
#include <stm32g0xx_hal.h>
#include <stm32g0xx_hal_flash.h>
#include <stm32g0xx_hal_flash_ex.h>

#include "Config.h"
#include "Error.h"

// NOTE: This all very much relies on configs size being a multiple of 64bits
#define CONFIG_START_ADDRESS 0x8007800

union conf {
    Config confConf;
    uint32_t conf32[sizeof(Config)/4];
};


__attribute__((section(".config"))) static volatile union conf configuration;

Config readConfig(void) { // returns entire configuration data struct
    return configuration.confConf;
}

#define FLASH_USER_START_ADDR   (FLASH_BASE + (4 * FLASH_PAGE_SIZE))   /* Start @ of user Flash area */
#define FLASH_USER_END_ADDR     (FLASH_BASE + FLASH_SIZE - 1)   /* End @ of user Flash area */

#define DATA_64                 ((uint64_t)0x1234567812345678)
#define DATA_32                 ((uint32_t)0x12345678)

static uint32_t GetPage(uint32_t Addr)
{
  return (Addr - FLASH_BASE) / FLASH_PAGE_SIZE;;
}

uint8_t writeConfig(Config conf) { // writes new configuration data
    
    uint32_t numWords = sizeof(Config) / 4; // calculate how many multiples of 64bits are in the current Config struct
    uint32_t sizRemainder = sizeof(Config) % 8; // determine if there is a remainder
    union conf tmp;
    tmp.confConf = conf;

    //Unlock Flash
    FLASH->KEYR = 0x45670123;
    FLASH->KEYR = 0xCDEF89AB;

    while(FLASH->SR & FLASH_SR_BSY1 || FLASH->SR & FLASH_SR_CFGBSY);

    // Erase Config Page
    FLASH->CR |= FLASH_CR_PER; // Set Page Erase bit
    // FLASH->CR &= ~FLASH_CR_BKER; // this device doesn't have this bit
    FLASH->CR |= (0x0F) << 3; // set page 15 to be erased
    FLASH->CR |= FLASH_CR_STRT; // start erase

    while(FLASH->SR & FLASH_SR_CFGBSY || FLASH->SR & FLASH_SR_BSY1); // wait for erase to finish
    FLASH->CR &= ~FLASH_CR_PER;

    // Write new config page
    // TODO: Clear Any Errors
    
    while(FLASH->SR & FLASH_SR_CFGBSY || FLASH->SR & FLASH_SR_BSY1); // make sure flash isn't busy
    FLASH->CR |= FLASH_CR_PG; // Set Program bit

    configuration.confConf.magic =               conf.magic;
    configuration.confConf.structVersion =       conf.structVersion;
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.firmwareVersion =          conf.firmwareVersion;
    configuration.confConf.pressureMin[0] =         conf.pressureMin[0];
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.pressureMin[1] =         conf.pressureMin[1];
    configuration.confConf.pressureMin[2] =         conf.pressureMin[2];
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.pressureMax[0] =         conf.pressureMax[0];
    configuration.confConf.pressureMax[1] =         conf.pressureMax[1];
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.pressureMax[2] =         conf.pressureMax[2];
    configuration.confConf.numLongTermAvgSamples =  conf.numLongTermAvgSamples;
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.numShrtTermAvgSamples =  conf.numShrtTermAvgSamples;
    configuration.confConf.pressThreshold =         conf.pressThreshold;
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.releaseThreshold =       conf.releaseThreshold;
    configuration.confConf.maxThreshold =           conf.maxThreshold;
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    configuration.confConf.colourHueStart =         conf.colourHueStart;
    configuration.confConf.colourHueEnd =           conf.colourHueEnd;
    while(FLASH->SR & FLASH_SR_CFGBSY); // wait for program operation to finish
    // while(!(FLASH->SR & FLASH_SR_EOP)); // wait for end of program flag to set
    FLASH->SR &= ~FLASH_SR_EOP;

    FLASH->CR &= ~FLASH_CR_PG;
    FLASH->CR |= FLASH_CR_LOCK;
}

#ifdef __cplusplus
}
#endif