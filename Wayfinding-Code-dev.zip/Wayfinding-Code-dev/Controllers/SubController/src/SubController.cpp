

#include <Arduino.h>

#include "firmwareUpdating.h"
#include "pins.h"
#include "NeoPixel.h"
#include "i2cComs.h"
#include "modes.h"
#include "pressureSensors.h"

#include "Config.h"


#define DATA_COLOUR 1
#define DATA_MODE 2
#define DATA_CONFIG 3
#define DATA_REQUEST 4
#define DATA_CONFIG_ID 10

#define REQUEST_PRESSURE 0
#define REQUEST_PRESS_COUNT 1

// Globals
extern volatile uint8_t pressure;

extern uint16_t sens_min[NUM_SENS];
extern uint16_t sens_max[NUM_SENS];

// NeoPixel Globals
extern bool LED_FLASH;
extern bool LED_SOLID;


uint8_t request;


// uint32_t received_time = 0;
// #define FLASH_TIME 500

static uint32_t lastRead = 0;
static uint32_t now;

// // ======== CELL CONFIG VARIABLES ========
// #define CFG_QTY 8  //Number of configuration variables

// #define CFG_LT_AVG 0
// #define CFG_ST_AVG 1
// #define CFG_BRIGHT 2
// #define CFG_RETRIG 3
// #define CFG_PRESS_THR 4
// #define CFG_RELEASE_THR 5
// #define CFG_MAX_THR 6
// #define CFG_SAMPLE_TIME 7



// uint8_t config[CFG_QTY] = {
//   100,     //Long term average samples(stored as 1/10th of its value)
//   10,      //Short term average samples
//   255,     //Global LED brightness
//   10,      //Retrigger time (stored as 1/10th of its value)
//   20,      //pressre threshold (.08*255)
//   13,  //pressure release threshold (.05*255)
//   179,   //maximum pressure threshold (.7*255)
//   5        //sampling time
// };

void pin_init(void){

  //Initialize dip switches
  for (int i=0; i <6; i++) 
  {    pinMode(I2C_ADDRESS_PINS[i], INPUT_PULLUP);  }
  pinMode(CELL_TYPE_PIN,INPUT_PULLUP);

  //Initialize pressure sensors
  for (int i=0; i <3; i++) 
  {    pinMode(PIN_SENSE[i], INPUT_ANALOG);   }

  //Initialize status LEDs
  for (int i=0; i <2; i++) 
  {    pinMode(PIN_STATUS[i], OUTPUT);   }

}

uint8_t cell_type;
void check_cell_type() {
  if (!digitalRead(CELL_TYPE_PIN)) {
    cell_type = CELL_TYPE_SELECTOR;
    centre_leds_on();
    led_show();
    delay(1500);
    centre_leds_on(0);
    led_show();
  } else {
    cell_type = CELL_TYPE_NORMAL;
  }
}

void load_config(){

  Config tmp = readConfig();
  for (int i = 0; i<NUM_SENS; i++) {
      sens_min[i] = tmp.pressureMin[i];
      sens_max[i] = tmp.pressureMax[i];
  }
}

void setup() {
  neopixel_init();
  endUpdate();
  pin_init();
  check_cell_type();
  I2C_init_STM();
  load_config();

}

#define LOOP_TIME 5
void loop() {

  now = millis();
  // if (now - lastRead >= config[CFG_SAMPLE_TIME]) {
  if (now - lastRead >= LOOP_TIME) {
    lastRead = now;
    sample_all();
    if (cell_type == CELL_TYPE_SELECTOR) {hold_check();}
    LED_update_mode(pressure);
  }

}