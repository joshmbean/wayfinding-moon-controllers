#include "commands.h"
#include <Arduino.h>
#include <modes.h>
#include "NeoPixel.h"

#include "firmwareUpdating.h"

extern void led_fill_HSV(uint16_t hue, uint8_t saturation, uint8_t value);
extern void led_fill_hue(uint16_t hue);

extern uint32_t LED_RGB;
extern bool LED_FLASH; // 0 = don't flash, 1 = flash once
extern bool LED_SOLID; // 0 = not solid, 1 = go solid

uint8_t commandHandler(uint8_t cmd, uint8_t *data, uint8_t size) { 
    uint8_t type = (cmd & 0xF0); // extract command type we received
    switch (type) {
        case (uint8_t)CMD_TYPE_DIAG:
        handleDiagCmd(cmd);
        break;

        case (uint8_t)CMD_TYPE_MODE:
        handleModeCmd(cmd);
        break;

        case (uint8_t)CMD_TYPE_CONF:
        handleConfCmd(cmd, data, size);
        break;

        case (uint8_t)CMD_TYPE_INST: // Instruction Commands
        handleInstCmd(cmd);
        break;

        case (uint8_t)CMD_TYPE_COLS: // Colour Solid Commands
        handleColSoldCmd(cmd);
        break;

        case (uint8_t)CMD_TYPE_COLF: // Colour Flash Commands
        handleColFlshCmd(cmd);
        break;

        default:
        // BAD THINGS HERE
        uint16_t hue = map(120, 1, 255, 0, 65535);
        led_fill_hue(hue);
        break;
    }
    return 0;
}

// Command Type Handlers
uint8_t handleDiagCmd(uint8_t cmd) {
    switch(cmd){
        case (uint8_t)CMD_STATUS:
        break;
        case (uint8_t)CMD_RESET:
        break;
        case (uint8_t)CMD_BLINK:
        break;
        case (uint8_t)CMD_UPDATE_FW:
        startUpdate();
        break;
        default:
        uint16_t hue = map(120, 1, 255, 0, 65535);
        led_fill_hue(hue);
    }

}

uint8_t handleModeCmd(uint8_t cmd) {
    set_mode(cmd);
    return 0;
}

uint8_t handleConfCmd(uint8_t cmd, uint8_t *data, uint8_t size) {

}



uint8_t handleInstCmd(uint8_t cmd) {
    switch (cmd) {
        case CMD_INST_LEDON:
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;
        case CMD_INST_LEDOFF:
        LED_SOLID = 0;
        LED_FLASH = 0;
        break;
        case CMD_INST_LEDFLASH:
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;
        default:

        break;
    }

}

uint8_t handleColSoldCmd(uint8_t cmd) { // Set flag to turn on LED in specific colour
    switch (cmd) {
        case CMD_COLSOLD_00:
        LED_RGB = LED_COLOUR_00;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_01:
        LED_RGB = LED_COLOUR_01;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_02:
        LED_RGB = LED_COLOUR_02;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_03:
        LED_RGB = LED_COLOUR_03;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_04:
        LED_RGB = LED_COLOUR_04;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_05:
        LED_RGB = LED_COLOUR_05;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_06:
        LED_RGB = LED_COLOUR_06;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_07:
        LED_RGB = LED_COLOUR_07;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_08:
        LED_RGB = LED_COLOUR_08;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_09:
        LED_RGB = LED_COLOUR_09;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_10:
        LED_RGB = LED_COLOUR_10;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_11:
        LED_RGB = LED_COLOUR_11;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_12:
        LED_RGB = LED_COLOUR_12;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_13:
        LED_RGB = LED_COLOUR_13;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_14:
        LED_RGB = LED_COLOUR_14;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;

        case CMD_COLSOLD_15:
        LED_RGB = LED_COLOUR_15;
        LED_SOLID = 1;
        LED_FLASH = 0;
        break;
    }
}


uint8_t handleColFlshCmd(uint8_t cmd) { // Set flag to flash LED once 
    switch (cmd) {
        case CMD_COLFLSH_00:
        LED_RGB = LED_COLOUR_01;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_01:
        LED_RGB = LED_COLOUR_02;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_02:
        LED_RGB = LED_COLOUR_03;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_03:
        LED_RGB = LED_COLOUR_03;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_04:
        LED_RGB = LED_COLOUR_04;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_05:
        LED_RGB = LED_COLOUR_05;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_06:
        LED_RGB = LED_COLOUR_06;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_07:
        LED_RGB = LED_COLOUR_07;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_08:
        LED_RGB = LED_COLOUR_08;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_09:
        LED_RGB = LED_COLOUR_09;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_10:
        LED_RGB = LED_COLOUR_10;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_11:
        LED_RGB = LED_COLOUR_11;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_12:
        LED_RGB = LED_COLOUR_12;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_13:
        LED_RGB = LED_COLOUR_13;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_14:
        LED_RGB = LED_COLOUR_14;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;

        case CMD_COLFLSH_15:
        LED_RGB = LED_COLOUR_15;
        LED_SOLID = 0;
        LED_FLASH = 1;
        break;
    }
    return 0;
}
