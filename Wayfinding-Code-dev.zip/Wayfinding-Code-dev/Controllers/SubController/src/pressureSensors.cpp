#include "pressureSensors.h"

#include "pins.h"
#include "modes.h"
#include "commands.h"

extern uint8_t selected_mode;
extern bool mode_selection_active;


// Globals
uint8_t pressure;
uint8_t pressure_max;

uint8_t sens_pressure[NUM_SENS];
uint16_t sens_max[NUM_SENS];
uint16_t sens_min[NUM_SENS];
uint16_t sens_max_new[NUM_SENS];
uint16_t sens_min_new[NUM_SENS];


 
uint8_t pressed = false;
uint8_t press_count = 0;
uint8_t release_count = 0;
uint64_t press_time = 0;
uint64_t release_time = 0;

// ======== ADC / FILTERING ========

#define AVG_SAMPLES 20

uint16_t voltage_sample[NUM_SENS][AVG_SAMPLES];
uint16_t voltage_avg[NUM_SENS];
#define VOLTAGE_AVG_SCALE 10000
// float LTAvg[NUM_SENS];
// float STAvg[NUM_SENS];
uint64_t sample_count;
uint8_t sample_index =0;

uint16_t retrigger_time = 100;

//maps a floating point to an integer range and constrains it
// int floatmap(float value, float fromLow, float fromHigh, int toLow, int toHigh) {
//   int val = (value - fromLow) / (fromHigh - fromLow) * (toHigh - toLow) + toLow;
//   if (val > toHigh) { val = toHigh; }
//   if (val < toLow) { val = toLow; }
//   return val;
// }

void sample_all() {
  // uint16_t val;
  uint16_t temp_pressure = 0;
  for (int side = 0; side < NUM_SENS; side++) {
    // val = analogRead(PIN_SENSE[side]);                                            //read sensor
    voltage_sample[side][sample_index] = analogRead(PIN_SENSE[side]);                                            //read sensor
    voltage_avg[side] = 0;
    for (int sample = 0; sample < AVG_SAMPLES; sample++){
      voltage_avg[side] += voltage_sample[side][sample];
    }
    // voltage_avg[side] = (uint64_t(val)*VOLTAGE_AVG_SCALE + (AVG_SAMPLES - 1) * voltage_avg[side]) / AVG_SAMPLES;    //add value to short term average

    
    // STAvg[side] = (val + (ST_AVG_SAMPLES - 1) * STAvg[side]) / ST_AVG_SAMPLES;    //add value to short term average
    // if (!pressed) {                                                               //if state is not pressed
    //   LTAvg[side] = (val + (LT_AVG_SAMPLES - 1) * LTAvg[side]) / LT_AVG_SAMPLES;  //add value to long term average only if not currently pressed
    // }
    if (get_mode() == MODE_CALIBRATION) {
      if (sample_count>AVG_SAMPLES){
        sens_min_new[side] = uint16_t (min(int(sens_min_new[side]),int(voltage_avg[side])));
        sens_max_new[side] = uint16_t (max(int(sens_max_new[side]),int(voltage_avg[side])));
        // sens_min_new[side] = uint16_t (min(int(sens_min_new[side]),int(voltage_avg[side]/VOLTAGE_AVG_SCALE)));
        // sens_max_new[side] = uint16_t (max(int(sens_max_new[side]),int(voltage_avg[side]/VOLTAGE_AVG_SCALE)));
      }
      // sens_pressure[side] = map(val,0,2000,0,255);      
      sens_pressure[side] = uint8_t (map(int(sens_min_new[side]),0,2000,0,255));      

    }
    else
    {
      sens_pressure[side] = constrain(map(int(voltage_avg[side]),int(sens_max[side]),int(sens_min[side]),0,255),0,255);
      // sens_pressure[side] = constrain(map(voltage_avg[side]/VOLTAGE_AVG_SCALE,int(sens_max[side]),int(sens_min[side]),0,254),0,254);
    }
    temp_pressure+= sens_pressure[side];
    // float_pressure += (1 - STAvg[side] / LTAvg[side]) / 3;
  }

  sample_index = (sample_index+1) % AVG_SAMPLES;
  sample_count ++;

  if (sample_count>AVG_SAMPLES){
    pressure = temp_pressure/NUM_SENS;
  } else {
    pressure = 0;
  }
  if (pressed) {
    pressure_max = uint8_t(max(int(pressure_max), int(pressure)));
    if (pressure < PRESSURE_RELEASE_THRESHOLD) {
      pressed = false;
      release_time = millis();
      release_count++;
    }
  } else {
    if ((millis() - release_time) > retrigger_time) {
      if (pressure > PRESSURE_THRESHOLD) {
        pressed = true;
        pressure_max = pressure;
        press_time = millis();
        press_count++;
      }
    }
  }
  if (!pressed) { pressure = 0; }
}

#define HOLD_TIME 5000
#define IDLE_TIME 5000
bool hold_check(){
  if (mode_selection_active) {
    if (!pressed && ((millis()-release_time) >IDLE_TIME)) {
      choose_mode();
      return 0;
    }
    increment_selected_mode();
    return 0; 
  }
  if (pressed && ((millis()-press_time) > HOLD_TIME)){
    activate_mode_selection();
    return 1;
  }
  return 0;
}