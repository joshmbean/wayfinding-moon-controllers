#include <Arduino.h>

#include "Error.h"


#include "pins.h"

extern void led_fill_HSV(uint16_t hue, uint8_t saturation, uint8_t value);
extern void led_fill_hue(uint16_t hue);
extern void led_show();
extern void led_off();


void error(void) {
    // This function allows us to notify the outside world that something bad has happened
    while(1) {
        digitalWrite(PIN_STATUS[0], HIGH);
        delay(250);
        digitalWrite(PIN_STATUS[0], LOW);
        delay(250);
    }
}