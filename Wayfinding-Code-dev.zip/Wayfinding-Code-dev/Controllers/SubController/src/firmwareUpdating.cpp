// This file contains functions handling firmware updates
#include <Arduino.h>

#include <stm32g030xx.h>
#include <stm32g0xx_hal.h>
// #include <stdint.h>

#include "firmwareUpdating.h"

extern void led_fill_HSV(uint16_t hue, uint8_t saturation, uint8_t value);
extern void led_fill_hue(uint16_t hue);
extern void led_show();
extern void led_off();


void startUpdate(void) {
  // this function handles putting the hardware in a safe state before triggering a jump 
  // to the ST Bootloader. This function should be called when a Firmware Update Command is received

  // Update Procedure
  // 1. Disable Interrupts
  // 2. Disable Periperhals
  // 3. Clear nBoot0 bit
  // 4. Jump to Bootloader
  // All other functions are handled by the ROM Bootloader via I2C

  // Turn Cell LEDs on so we have a visual indicator of the process starting.
  // We do this instead of the status leds so that A it can be seen while firmware is actively updating
  // and B to actually see a status LED turn on we'd need a delay which would slow down the firmware update time
  uint16_t hue = map(255, 1, 255, 0, 65535);
  led_fill_hue(hue);
  led_show();

  // Unlock Flash CR
  FLASH->KEYR = 0x45670123;
  FLASH->KEYR = 0xCDEF89AB;

  // Unlock option byte flash
  FLASH->OPTKEYR = 0x08192A3B;
  FLASH->OPTKEYR = 0x4C5D6E7F;
  while(FLASH->CR & FLASH_CR_OPTLOCK); // wait for optlock to clear
  FLASH->OPTR &= ~FLASH_OPTR_nBOOT0; // clear nBoot0 bit, this will trigger the ROM bootloader to run next reset
  while(FLASH->SR & FLASH_SR_BSY1); // wait for all ongoing flash operations to finish
  FLASH->CR |= FLASH_CR_OPTSTRT;
  while(FLASH->SR & FLASH_SR_BSY1); // wait for all ongoing flash operations to finish
  FLASH->CR |= FLASH_CR_OBL_LAUNCH; // setting this triggers a reset upon completion of the option bytes will be reloaded to their new values
  // This will never return since OBL LAUNCH triggers a reset

}

void endUpdate(void) {
  // This function runs at the beginning of every software startup and checks for if
  // the nBoot0 bit is cleared. If it is cleared then we set nBoot0 and trigger a reset.
  // this ensures that we won't accidentally go back to the bootloader in case of a power loss.
  // Finally we set the LEDs blue and when the main controller queries we send a FW_UP_OK response.

  if (FLASH->OPTR & FLASH_OPTR_nBOOT0) {
    // No firmware update has occured since the last boot
      uint16_t hue = map(200, 1, 255, 0, 65535);
    led_fill_hue(hue);
    led_show();
    delay(2000);
    led_off();
    led_show();

    return;
  }

  // A firmware update has occured since the last boot 
  // Unlock Flash CR
  FLASH->KEYR = 0x45670123;
  FLASH->KEYR = 0xCDEF89AB;

  // Unlock option byte flash
  FLASH->OPTKEYR = 0x08192A3B;
  FLASH->OPTKEYR = 0x4C5D6E7F;
  while(FLASH->CR & FLASH_CR_OPTLOCK); // wait for optlock to clear
  FLASH->OPTR |= FLASH_OPTR_nBOOT0; // set nBoot0 bit, this will trigger our firmware to run on subsequent reboots
  while(FLASH->SR & FLASH_SR_BSY1); // wait for all ongoing flash operations to finish
  FLASH->CR |= FLASH_CR_OPTSTRT;
  while(FLASH->SR & FLASH_SR_BSY1); // wait for all ongoing flash operations to finish
  
  // Set LEDs to Blue to indicate handling of the firmware update is about to finish (since we're about to reboot again)
  uint16_t hue = map(128, 1, 255, 0, 65535);
  led_fill_hue(hue);
  led_show();
  delay(2000);
  // NOTE: This may not be required since we won't ever read these bits but also
  // we don't know if the HAL cares about them so probably good to reset anyway in case it cares
  FLASH->CR |= FLASH_CR_OBL_LAUNCH; // setting this triggers a reset upon completion of the option bytes will be reloaded to their new values
  // This will never return since OBL LAUNCH triggers a reset



}