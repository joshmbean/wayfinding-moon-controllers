#include <modes.h>
#include <pressureSensors.h>
#include <pins.h>
#include "NeoPixel.h"

#include "Config.h"

extern uint16_t sens_min[NUM_SENS];
extern uint16_t sens_max[NUM_SENS];
extern uint16_t sens_min_new[NUM_SENS];
extern uint16_t sens_max_new[NUM_SENS];

extern uint8_t pressure_max;
extern uint64_t sample_count;
extern uint8_t press_count;
extern uint8_t release_count;
extern uint64_t press_time;
extern uint64_t release_time;
volatile uint8_t mode = MODE_COLOUR;


extern uint8_t colSequenceIndex;

void set_mode(uint8_t new_mode) {
    led_off();
    led_show();
    colSequenceIndex = 0;
    if (new_mode == mode) {return;}
    //reset counters
    press_count = release_count = 0;
    press_time = release_time = 0;

    if (mode == MODE_CALIBRATION && new_mode == MODE_CALIBRATION_SAVE) {
        Config tmp = readConfig();
        for (int i = 0; i<NUM_SENS; i++) {
            sens_min[i] = sens_min_new[i];
            sens_max[i] = sens_max_new[i];

            tmp.pressureMin[i] = uint32_t( sens_min[i] );
            tmp.pressureMax[i] = uint32_t( sens_max[i] );

        }
        writeConfig(tmp);

    }
    if( new_mode == MODE_CALIBRATION) {
    //initialize min and max values
        for (int side=0; side<NUM_SENS; side++) {
            sens_min_new[side] = 4095;
            sens_max_new[side] = 0;
            sample_count = 0;
            
        }
    }
    mode = new_mode;

    pressure_max = 0;
    return;
}
uint8_t get_mode() {
    return mode;
}

uint8_t selected_mode;
uint8_t chosen_mode;

bool mode_selection_active = false;

const uint8_t selection_modes[MODE_SELECTION_QTY]  =  {MODE_COLOUR,MODE_SIMON_DISPLAY,MODE_PRESSURE,MODE_ORBIT,MODE_MOTH,MODE_MUSIC};

void activate_mode_selection(){
    mode_selection_active = true;
    for (int i=0; i<MODE_SELECTION_QTY; i++){
        if (selection_modes[i] == mode) {
            selected_mode = i;
            return;
        }
    }
    selected_mode = 0;
}

uint8_t get_selected_mode(){
    return selected_mode;
}


void increment_selected_mode() {
    selected_mode = (selected_mode+press_count) % MODE_SELECTION_QTY;
    press_count = 0;
}

void choose_mode() {
    chosen_mode = selection_modes[selected_mode];
    mode_selection_active = false;
}