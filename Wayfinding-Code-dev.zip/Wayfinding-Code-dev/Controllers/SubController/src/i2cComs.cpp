
#include "i2cComs.h"

#include <Arduino.h>
#include <Wire.h>
#include <pins.h>
#include <pressureSensors.h>
#include "commands.h"

#include "NeoPixel.h"

// Globals
extern uint8_t pressure;
extern uint8_t press_count;
extern uint8_t release_count;
extern uint8_t mode;
extern bool LED_SOLID; 

long received_time;

//I2C functions
void I2Csend() {
  uint8_t data;
  switch (mode) {
    case CMD_SET_MODE_COLOUR: // Reply with colour
      data = getColSequenceIndex(); // Send the current colour
     
    break;

    case CMD_SET_MODE_PRESSURE: // Reply with mapped pressure between 0-127
      data = map(pressure, 0, 255, 0, 127);
    break;
    case  CMD_SET_MODE_MUSIC:
      data = pressure;
    break;
    case CMD_SET_MODE_SIMON_REACT:
    case CMD_SET_MODE_MOTH:

    case CMD_SET_MODE_FLASH:
      data = ((release_count & 0x0F) << 4) + (press_count & 0x0F);
      press_count = release_count = 0;
    break;
    case CMD_SET_MODE_STANDBY:
      if (LED_SOLID) {  //if we're on the light side of the moon
        data = map(pressure, 0, 255, 0, 127);
      } else {
        data = 0x80 + getColSequenceIndex(); // Send the current colour with the MSB = 1 to signify that this is colour not pressure data
      }
    break;
    default:
      data = 0;
    break;
  }

  Wire.write(data);
  digitalWrite(PIN_STATUS[0],!digitalRead(PIN_STATUS[0]));

}

void I2Creceive(int bytesReceived) {
  
  if ((bool)bytesReceived) {  //If received more than zero bytes
    received_time = millis();
    uint8_t cmd = Wire.read();
    uint8_t data[4];
    for(int i=0; i<(bytesReceived-1); i++) {
        if (i>=4) {break;}
        data[i] = Wire.read();
    }

    commandHandler(cmd,data,bytesReceived-1);
    }
  digitalWrite(PIN_STATUS[1],!digitalRead(PIN_STATUS[1]));
  }



void I2C_init_STM(void){
  uint8_t I2C_address = 0;

  for (int i=0; i<6; i++) 
  {
    I2C_address = I2C_address  + (!digitalRead(I2C_ADDRESS_PINS[i]) << i);
  }

  Wire.setSCL(I2C_SCL);
  Wire.setSDA(I2C_SDA);
  Wire.begin(I2C_address,true,true);
  Wire.onReceive(I2Creceive);
  Wire.onRequest(I2Csend);
}