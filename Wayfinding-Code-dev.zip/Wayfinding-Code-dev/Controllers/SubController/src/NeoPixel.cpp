#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <NeoPixel.h>

#include "modes.h"
#include "pins.h"
#include "pressureSensors.h"

extern uint8_t sens_pressure[NUM_SENS];
extern uint16_t sens_max[NUM_SENS];
extern uint16_t sens_min[NUM_SENS];
extern uint16_t sens_max_new[NUM_SENS];
extern uint16_t sens_min_new[NUM_SENS];
extern long received_time;


extern uint8_t press_count;
extern uint8_t pressure_max;

extern uint64_t press_time;
extern uint64_t release_time;
extern uint8_t cell_type;
extern bool mode_selection_active;

uint32_t LED_RGB;
uint32_t last_colour;
bool LED_FLASH; // Flag to tell LED To flash once
bool LED_SOLID; // Flag to turn the led solid
const uint8_t selection_mode_LEDs[MODE_SELECTION_QTY] = {4,6,8,10,12,14};
const uint32_t selection_mode_colours[MODE_SELECTION_QTY] = {0x000000FF,0x00008080,0x0000FF00,0x00808000,0x00FF0000,0x00800080};


Adafruit_NeoPixel strip = Adafruit_NeoPixel(NUM_LEDS, PIN_LED, NEO_GRB + NEO_KHZ800);

bool ledOn = false;
uint8_t led_colour_num = 0;


 uint8_t colSequenceIndex = 1; // Track where in the pre-mapped colour sequence we are
 uint32_t colourSequence[] = {LED_COLOUR_00, LED_COLOUR_01, LED_COLOUR_02, LED_COLOUR_03, LED_COLOUR_04, LED_COLOUR_05, LED_COLOUR_06, LED_COLOUR_07, 
                               LED_COLOUR_08, LED_COLOUR_09, LED_COLOUR_10, LED_COLOUR_11, LED_COLOUR_12, LED_COLOUR_13, LED_COLOUR_14, LED_COLOUR_15};

uint8_t getColSequenceIndex() {
  return colSequenceIndex;
}

void led_off() {
  strip.clear();
}

void led_show() {
  strip.show();
}
void led_fill_col(uint32_t col) {
    for(int i=0; i<CELL_LEDS; i++){
      strip.setPixelColor(i,col);
    }
}

void led_fill_HSV(uint16_t hue, uint8_t saturation, uint8_t value) {
  if (hue == 0 & saturation == 0) {
    led_off();
  } else {
    uint32_t col = strip.ColorHSV(hue, saturation, value);
    led_fill_col(col);
  }
}

void led_fill_hue(uint16_t hue) {
  led_fill_HSV(hue, 255, 255);
}

uint32_t scaleRGB(uint32_t col,uint8_t scale) {
  uint8_t bit;
  uint32_t new_col;
  for (int i=0; i<4;i++){
    bit = (col >> (i*8)) & 0xff;
    bit = (bit*scale) /255;
    new_col += (bit >> (i*8));
  }
  return new_col;
}

uint32_t mixRGB(uint32_t col1,uint32_t col2,uint8_t mixture) {
  uint8_t anti_mixture = 255 - mixture;
  uint16_t part1, part2;
  uint32_t new_col = 0;
  uint8_t new_part;
  for (int i=0; i<4;i++){
    part1 = ((col1 >> (i*8)) & 0xff) * mixture;
    part2 = ((col1 >> (i*8)) & 0xff) * anti_mixture;
    new_part = (part1+part2) /255;
    new_col += (new_part >> (i*8));
  }
  return new_col;
}

#define FLASH_TIME 500
//Flash leds when pressed with communication to central controller
void LED_mode_flash() {
  static uint32_t onTime = 0;

  if (LED_FLASH && onTime == 0) {
    onTime = millis();
    led_fill_col(LED_RGB);
    led_show();
  } else if (LED_FLASH && (millis() - onTime) >= FLASH_TIME) {
    LED_FLASH = 0;
    onTime = 0;
    led_off();
  } else if (LED_SOLID) {
    led_fill_col(LED_RGB);
    led_show();
  }
  // if (millis()<received_time + FLASH_TIME) {
  //   led_fill_col(LED_RGB);
  // }
  // else {
  //   led_off();
  // }
}

#define SENS_ERROR_FLASH_TIME 500
void LED_mode_calibrate() {

  uint32_t col;
  if (get_mode()==MODE_CALIBRATION) {
    for (int side=0; side<NUM_SENS; side++){
      col = strip.ColorHSV(uint16_t(map(int(sens_pressure[side]), 0, 255, 0, 65535)),255,255);
      strip.setPixelColor(side,col);
    }
  }
  else if (get_mode()==MODE_CALIBRATION_SAVE) {
    for (int side=0; side<NUM_SENS; side++){
      if ((sens_max[side] - sens_min[side]) < SEN_MIN_DIFF) {
        if ((millis()/SENS_ERROR_FLASH_TIME) % 2 ) {
          col = strip.ColorHSV(0,255,255);          
        }
        else {
          col = strip.ColorHSV(0,255,0);          
        }
      }
      else {
        col = strip.ColorHSV(uint16_t(map(int(sens_pressure[side]), 0, 254, 0, 65535)),255,255);
      }
      strip.setPixelColor(side,col);
    }
  }
}

// #define FADE_COLOUR LED_COLOUR_15
#define FADE_TIME 2000
//update LEDs based on pressure
void LED_mode_pressure(uint8_t pressureA) {
  static uint32_t colour;
  uint8_t mixture;
  uint16_t hue = constrain(map(int(pressure_max), PRESSURE_THRESHOLD, PRESSURE_MAX_THRESHOLD, 0, 65535),0,65535);
  if (pressureA > 0) {
    colour = strip.ColorHSV(hue,255,255);
    // led_fill_hue(hue);
  } else {
    uint32_t elapsed = millis()-release_time;
    if (elapsed < FADE_TIME) {
      mixture = map(elapsed,0,FADE_TIME,255,0);
      colour = mixRGB(LED_RGB,colour,mixture);
      // led_fill_HSV(hue,255,map(elapsed,0,FADE_TIME,255,0));
    } else {
      colour = LED_RGB;
    }
  }
  led_fill_col(colour);
  last_colour = colour;
}

void centre_leds_on(uint32_t col){
    strip.fill(col,CELL_LEDS,MODE_LEDS);}

void centre_leds_on(){
    centre_leds_on(0x00FFFFFF);
}
void led_show_mode() {
  uint8_t led_on = (millis()/100) % MODE_LEDS;
  if (!mode_selection_active) {
    strip.fill(0,CELL_LEDS,MODE_LEDS);
    return;
  }
  uint8_t selected_mode = get_selected_mode();
  for (int i=CELL_LEDS;i<NUM_LEDS; i++) {
    if (i == selection_mode_LEDs[selected_mode]) {
      strip.setPixelColor(i,selection_mode_colours[selected_mode]);
    }
    else {
      strip.setPixelColor(i,0);
    }
  }
}

void LED_mode_moth(uint8_t pressureA) {
  // if (pressureA > 0) {
  //   uint8_t value = map(pressureA, 1, 255, MODE_MUSIC_DEFAULT_VALUE, 255);
  //   led_fill_col(scaleRGB(LED_RGB,value));
  // } else {
  //   led_fill_col(scaleRGB(LED_RGB, MODE_MUSIC_DEFAULT_VALUE));
  // }
}

void LED_mode_music(uint8_t pressureA) {
  // if (pressureA > 0) {
  //   uint8_t value = map(pressureA, 1, 255, MODE_MUSIC_DEFAULT_VALUE, 255);
  //   led_fill_col(scaleRGB(LED_RGB,value));
  // } else {
  //   led_fill_col(scaleRGB(LED_RGB, MODE_MUSIC_DEFAULT_VALUE));
  // }
}

void LED_mode_colour() {
  bool updated = (press_count > 0);
  // led_colour_num += press_count;
  press_count = 0;
  // led_colour_num = led_colour_num % MODE_COLOUR_QTY;

 
  if (updated) {
    uint32_t colour;
    if (!colSequenceIndex) { // transition from off to colour 1
      colSequenceIndex = 1;
    } else {
      colSequenceIndex += 2; // increment by two to next in sequence to go to every other colour
    }
    if (colSequenceIndex > 14) { // loop back to beginning of sequence
      colSequenceIndex = 0;
    }
    
    if (colSequenceIndex) {
      colour = colourSequence[colSequenceIndex];
      // led_show();
    } else {
      colour = 0; // when sequence is zero turn off (we don't use colour zero)
    }
    // uint16_t hue = map(led_colour_num - 1, 0, MODE_COLOUR_QTY - 1, 0, 65535);
    // led_fill_hue(hue);
    led_fill_col(colour);
    last_colour = colour;
  }
}

void LED_mode_simon() {
  switch (get_mode()) {
    case MODE_SIMON_DISPLAY:
      led_fill_col(LED_RGB);
    break;
    case MODE_SIMON_REACT:

    break;
    default:
      return;
  }

}

#define ORBIT_FADE_TIME 1500
void LED_mode_orbit(uint8_t pressureA) {
  uint64_t elapsed = millis() - received_time;
  if (elapsed < ORBIT_FADE_TIME) {    //if the cell recently received new instructions (crossed the horizon)
    uint16_t new_colour;
    uint8_t mixture = map(elapsed,0,ORBIT_FADE_TIME,0,255);
    if(LED_SOLID) {                   //if the cell crossed onto the lit side of the moon: fade from previous colour to instructed colour
      new_colour = LED_RGB;
    } else {                          //if the cell crossed onto the dark side of the moon: fade from previous colour to off
      new_colour = 0;
    }
    led_fill_col (mixRGB(last_colour,new_colour,mixture));   //mix the last colour with the new colour to fade
    return;
  }

  if (LED_SOLID) {          //cell is fully on the lit side of  the moon
    LED_mode_pressure(pressureA);    //run it in pressure mode
  } else {                  //cell is fully on the dark side of the moon
    LED_mode_colour();      //run it in colour mode
  }
}

//update LEDs based on current mode
void LED_update_mode(uint8_t pressureA) {
  
  switch (get_mode()) {
    case MODE_PRESSURE:
      LED_mode_pressure(pressureA);
      break;
    // case MODE_MOTH:
    //   LED_mode_moth(pressureA);
    //   break;
    case MODE_MUSIC:
      LED_mode_music(pressureA);
      break;
    case MODE_COLOUR:
      LED_mode_colour();
      break;
    case MODE_SIMON_DISPLAY:
    case MODE_SIMON_REACT:
      LED_mode_simon();
      break;
    case MODE_ORBIT:
      LED_mode_orbit(pressureA);
      break;
    case MODE_CALIBRATION:
    case MODE_CALIBRATION_SAVE:
      LED_mode_calibrate();
    case MODE_FLASH:
      LED_mode_flash();
    default:
      break;
  }
  if (cell_type == CELL_TYPE_SELECTOR) { 
    led_show_mode();
    // centre_leds_on(0x00FFFFFF);  
  }
  strip.show();
}

void neopixel_init(void) {
  strip.begin();
  strip.setBrightness(255);
  // strip.setBrightness(config[CFG_BRIGHT]);
  led_off();

}