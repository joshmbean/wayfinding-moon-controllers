#ifndef I2CCOMS_H
#define I2CCOMS_H

#include <Arduino.h>

// #define I2C_FREQ 25000
// #define I2C_TIMEOUT 100
#define I2C_SDA_PIN 33
#define I2C_SCL_PIN 32

void I2C_init_STM(void);

#endif