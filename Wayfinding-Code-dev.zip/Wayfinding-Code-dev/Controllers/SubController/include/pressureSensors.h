#ifndef PRESSURESENSORS_H
#define PRESSURESENSORS_H

#include <Arduino.h>

#include "pins.h"
#define SEN_MIN_DIFF 100 //the minimum difference between min and max sensor readings

#define PRESSURE_THRESHOLD 120
#define PRESSURE_RELEASE_THRESHOLD 110
#define PRESSURE_MAX_THRESHOLD 200

void sample_all();
bool hold_check();

#endif