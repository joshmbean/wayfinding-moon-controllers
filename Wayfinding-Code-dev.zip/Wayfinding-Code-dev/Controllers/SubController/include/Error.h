#ifdef __cplusplus
extern "C"
{
#endif

#include <Arduino.h>

#ifndef ERROR_H
#define ERROR_H

// Error handling functions for the SubController
void error(void); // The final boss of software error handlers

#endif

#ifdef __cplusplus
}
#endif