#ifndef PINS_H
#define PINS_H

#include <Arduino.h>

#define PIN_LED  PA12                 
#define CELL_LEDS  3
#define MODE_LEDS  12
#define NUM_LEDS CELL_LEDS+MODE_LEDS

#define NUM_SENS  3
static const uint8_t PIN_SENSE[NUM_SENS] = { PA0, PA2, PA1 };  // three sides on ADC2 pins

static const uint8_t PIN_STATUS[2] = { PC15, PC14};
static const uint8_t I2C_ADDRESS_PINS[6] = { PA3, PA4, PA5, PA6, PA7, PA8};

#define CELL_TYPE_PIN PA11 //using 7th dip switch to select which cell is the mode selector
#define CELL_TYPE_NORMAL 1
#define CELL_TYPE_SELECTOR 2 


#define I2C_SCL PB6
#define I2C_SDA  PB7


#endif