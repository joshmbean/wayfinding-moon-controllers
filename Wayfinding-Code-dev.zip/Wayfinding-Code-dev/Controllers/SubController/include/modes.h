#include <Arduino.h>
#include "commands.h"

#ifndef MODE_H

#define MODE_H
//==== MODES =======
// #define MODE_BASE 0
// #define MODE_MOTH 1
// #define MODE_MUSIC 2
// #define MODE_COLOUR 3
// #define MODE_SIMON_DISPLAY 4
// #define MODE_SIMON_REACT 5
// #define MODE_STANDBY 6
// #define MODE_CALIBRATE 7
// #define MODE_CALIBRATION_SAVE 8
// #define MODE_FLASH 9

#define MODE_PRESSURE CMD_SET_MODE_PRESSURE
#define MODE_MUSIC CMD_SET_MODE_MUSIC
#define MODE_SIMON_DISPLAY CMD_SET_MODE_SIMON_DISPLAY
#define MODE_SIMON_REACT CMD_SET_MODE_SIMON_REACT
#define MODE_CALIBRATION CMD_SET_MODE_CALIBRATION
// #define MODE_CALIBRATION_SAVE CMD_SET_MODE_TEST
#define MODE_CALIBRATION_SAVE CMD_SET_MODE_MOTH
#define MODE_MOTH 0xFF //CMD_SET_MODE_MOTH

#define MODE_COLOUR CMD_SET_MODE_COLOUR
#define MODE_ORBIT CMD_SET_MODE_STANDBY
#define MODE_FLASH CMD_SET_MODE_FLASH

#define MODE_COLOUR_QTY 7
#define MODE_MUSIC_DEFAULT_VALUE 50
#define MODE_MOTH_DEFAULT_VALUE 50
#define MODE_MOTH_SIMON_FLASH_TIME 500

#define MODE_SELECTION_QTY 6


void set_mode(uint8_t);
uint8_t get_mode();
void activate_mode_selection();
uint8_t get_selected_mode();
void increment_selected_mode();
void choose_mode();
#endif