#ifndef COMMANDS_H
#define COMMANDS_H

#include <Arduino.h>
#include <stdint.h>

// Command Types
#define CMD_TYPE_DIAG 0x00U // System / Diagnostic
#define CMD_TYPE_MODE 0x10U // Mode
#define CMD_TYPE_CONF 0x20U // Configuration
#define CMD_TYPE_INST 0x30U // Cell Instructions
#define CMD_TYPE_COLS 0x40U // Solid Colour Commands
#define CMD_TYPE_COLF 0x50U // Flash Colour Commands 

// System / Diagnostic Commands
#define CMD_STATUS 0x00U
#define CMD_RESET  0x01U
#define CMD_BLINK  0x02U
#define CMD_UPDATE_FW 0x0FU

// Mode Commands
#define CMD_SET_MODE_PRESSURE 0x10U
#define CMD_SET_MODE_MUSIC 0x11U
#define CMD_SET_MODE_SIMON_DISPLAY 0x12U
#define CMD_SET_MODE_SIMON_REACT 0x13U
#define CMD_SET_MODE_CALIBRATION 0x14U
#define CMD_SET_MODE_TEST 0x15U
#define CMD_SET_MODE_MOTH  0x16U
#define CMD_SET_MODE_COLOUR 0x17U
#define CMD_SET_MODE_STANDBY 0x18U
#define CMD_SET_MODE_FLASH   0x19U

// Configuration Commands
#define CMD_CONFIG_LONG_AVG_SAMPLES 0x20U
#define CMD_CONFIG_SHRT_AVG_SAMPLES 0x21U
#define CMD_CONFIG_BRIGHTNESS 0x22U
#define CMD_CONFIG_RETRIGGER_TIME 0x23U
#define CMD_CONFIG_SAMPLE_TIME 0x24U
#define CMD_CONFIG_PRESS_THRESH 0x25U
#define CMD_CONFIG_RELEASE_THRESH 0x26U
#define CMD_CONFIG_MAX_THRESH 0x27U
#define CMD_CONFIG_COLOUR_HUE_START 0x28U
#define CMD_CONFIG_COLOUR_HUE_END 0x29U

// Instruction Commands (These Set Colours on the Sub-Controller)
#define CMD_INST_LEDON 0x30U // Turn on LEDs
#define CMD_INST_LEDOFF 0x31U // Turn Off LEDs
#define CMD_INST_LEDFLASH 0x32U // Flash LEDs

// Colour Commands Solid
#define CMD_COLSOLD_00 0x40U
#define CMD_COLSOLD_01 0x41U
#define CMD_COLSOLD_02 0x42U 
#define CMD_COLSOLD_03 0x43U 
#define CMD_COLSOLD_04 0x44U
#define CMD_COLSOLD_05 0x45U
#define CMD_COLSOLD_06 0x46U
#define CMD_COLSOLD_07 0x47U
#define CMD_COLSOLD_08 0x48U
#define CMD_COLSOLD_09 0x49U
#define CMD_COLSOLD_10 0x4AU
#define CMD_COLSOLD_11 0x4BU
#define CMD_COLSOLD_12 0x4CU
#define CMD_COLSOLD_13 0x4DU
#define CMD_COLSOLD_14 0x4EU
#define CMD_COLSOLD_15 0x4FU

// Colour Commands Flash
#define CMD_COLFLSH_00 0x50U
#define CMD_COLFLSH_01 0x51U
#define CMD_COLFLSH_02 0x52U
#define CMD_COLFLSH_03 0x53U
#define CMD_COLFLSH_04 0x54U
#define CMD_COLFLSH_05 0x55U
#define CMD_COLFLSH_06 0x56U
#define CMD_COLFLSH_07 0x57U
#define CMD_COLFLSH_08 0x58U
#define CMD_COLFLSH_09 0x59U
#define CMD_COLFLSH_10 0x5AU
#define CMD_COLFLSH_11 0x5BU
#define CMD_COLFLSH_12 0x5CU
#define CMD_COLFLSH_13 0x5DU
#define CMD_COLFLSH_14 0x5EU
#define CMD_COLFLSH_15 0x5FU


uint8_t commandHandler(uint8_t cmd, uint8_t *data, uint8_t size);
// Command Type Handlers
uint8_t handleDiagCmd(uint8_t);
uint8_t handleModeCmd(uint8_t);
uint8_t handleConfCmd(uint8_t, uint8_t*,uint8_t);
uint8_t handleInstCmd(uint8_t);
uint8_t handleColSoldCmd(uint8_t);
uint8_t handleColFlshCmd(uint8_t);


// Command Handlers
// uint8_t handleStatusCmd();
// uint8_t handleResetCmd();
// uint8_t handleBlinkCmd();
// uint8_t handleUpdateFWCmd();
// uint8_t handleSetModeBaseCmd();
// uint8_t handleSetModeMusicCmd();
// uint8_t handleSetModeSimonCmd();
// uint8_t handleSetmodeCalibrationCmd();
// uint8_t handleSetModeMothCmd();
// uint8_t handleSetmodeColourCmd();
// uint8_t handleSetModeStandbyCmd();
// uint8_t handleSetmodeFlashCmd();
// uint8_t handleConfigLongAvgSamplesCmd();
// uint8_t handleShortAvgSampleCmd();
// uint8_t handleBrightnessCmd();
// uint8_t handleRetriggerTimeCmd();
// uint8_t handleSampleTimeCmd();
// uint8_t handlePressThreshCmd();
// uint8_t handleReleaseThreshCmd();
// uint8_t handleMaxThreshCmd();
// uint8_t handleColourHueStartCmd();
// uint8_t handleColourHueEndCmd();

#endif