#ifndef FIRMWARE_UPDATING_H
#define FIRMWARE_UPDATING_H

#include <Arduino.h>

void startUpdate(void);
void endUpdate(void);

#endif