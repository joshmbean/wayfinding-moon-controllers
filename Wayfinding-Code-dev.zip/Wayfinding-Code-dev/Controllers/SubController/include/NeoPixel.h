#ifndef NEOPIXEL_H
#define NEOPIXEL_H

#include <Arduino.h>

// Colour Scheme
// Red – #FF2A2A
// Orange-Red – #FF5A1F
// Orange – #FF8C00
// Golden Yellow – #FFCC33
// Yellow-Green – #C8FF3D
// Green – #4DFF4D
// Teal-Green – #2FFFD3
// Cyan – #29CFFF
// Sky Blue – #4DA0FF
// Blue – #3366FF
// Indigo – #5A2CFF
// Violet – #8A2BE2
// Purple – #B44CFF
// Magenta / Pink-Purple – #FF4CF2
// Pink – #FF7AD9
// White – #FFFFFF

#define LED_COLOUR_00 0x00FF2A2A // Red – #FF2A2A
#define LED_COLOUR_01 0x00FF5A1F // Orange-Red – #FF5A1F
#define LED_COLOUR_02 0x00FF8C00 // Orange – #FF8C00
#define LED_COLOUR_03 0x00FFCC33 // Golden Yellow – #FFCC33
#define LED_COLOUR_04 0x00C8FF3D // Yellow-Green – #C8FF3D
#define LED_COLOUR_05 0x004DFF4D // Green – #4DFF4D
#define LED_COLOUR_06 0x002FFFD3 // Teal-Green – #2FFFD3
#define LED_COLOUR_07 0x0029CFFF // Cyan – #29CFFF
#define LED_COLOUR_08 0x004DA0FF // Sky Blue – #4DA0FF
#define LED_COLOUR_09 0x003366FF // Blue – #3366FF
#define LED_COLOUR_10 0x005A2CFF // Indigo – #5A2CFF
#define LED_COLOUR_11 0x008A2BE2 // Violet – #8A2BE2
#define LED_COLOUR_12 0x00B44CFF // Purple – #B44CFF
#define LED_COLOUR_13 0x00FF4CF2 // Magenta / Pink-Purple – #FF4CF2
#define LED_COLOUR_14 0x00FF7AD9 // Pink – #FF7AD9
#define LED_COLOUR_15 0x00FFFFFF // White – #FFFFFF

uint8_t getColSequenceIndex();

void neopixel_init();
void LED_update_mode(uint8_t);
void led_show();
void led_off();
void led_fill_hue(uint16_t);
void centre_leds_on(uint32_t);
void centre_leds_on();
#endif