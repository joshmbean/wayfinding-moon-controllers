#ifdef __cplusplus
extern "C"
{
#endif

#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>
#include <stdint.h>

struct config { 
    uint32_t magic;             // magic value 
    uint32_t structVersion;     // version of this struct (this nominally also means version of the command set)
    uint32_t firmwareVersion;   // version of firmware
    uint32_t pressureMin[3];    // min pressure reading calibration data
    uint32_t pressureMax[3];    // max pressure reading calibration data
    uint32_t numLongTermAvgSamples;
    uint32_t numShrtTermAvgSamples;
    uint32_t pressThreshold;
    uint32_t releaseThreshold;
    uint32_t maxThreshold;
    uint32_t colourHueStart;
    uint32_t colourHueEnd;

};
typedef struct config Config;


Config readConfig(void);
uint8_t writeConfig(Config conf);

#endif

#ifdef __cplusplus
}
#endif